/**
 * SEERAAI PRO — Candidate Firebase Storage Security Rules Verification Suite (Phase F / 8B.6.7)
 * Target Ruleset: storage.rules.phase8b5.4.integrated.candidate
 * Target Project: demo-seeraai-test (isolated emulator only)
 *
 * Run with:
 *   firebase emulators:exec --config firebase.emulator.test.json --project demo-seeraai-test --only storage "npx tsx tests/storage.rules.test.ts"
 */
import fs from 'node:fs';
import path from 'node:path';

interface StorageTestResult {
  id: number;
  name: string;
  passed: boolean;
  detail?: string;
}

async function runStorageRulesSuite(): Promise<void> {
  let testingModule: any;
  try {
    testingModule = await import('@firebase/rules-unit-testing' as string);
  } catch {
    console.error(
      'BLOCKED: @firebase/rules-unit-testing is not installed and Java JRE / Firebase Storage Emulator is required.'
    );
    console.error(
      'Next step: Install Java JRE + devDependency @firebase/rules-unit-testing, then execute:\n  firebase emulators:exec --only storage "npx tsx tests/storage.rules.test.ts"'
    );
    process.exit(2);
  }

  const { initializeTestEnvironment, assertFails, assertSucceeds } = testingModule;
  const rulesPath = path.resolve(process.cwd(), 'storage.rules.phase8b5.4.integrated.candidate');
  const rules = fs.readFileSync(rulesPath, 'utf8');

  const testEnv = await initializeTestEnvironment({
    projectId: 'demo-seeraai-test',
    storage: {
      rules,
      host: '127.0.0.1',
      port: 9199,
    },
  });

  const INST_A = 'inst_oromia_a';
  const INST_B = 'inst_federal_b';
  const samplePdf = Buffer.from('%PDF-1.4\n%SEERAAI test');
  const samplePng = Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]);
  const oversizedBuffer = Buffer.alloc(51 * 1024 * 1024, 0x41);

  await testEnv.withSecurityRulesDisabled(async (ctx: any) => {
    const st = ctx.storage();
    await st.ref(`institutions/${INST_A}/courtDocuments/doc_a1/order.pdf`).put(samplePdf, { contentType: 'application/pdf' });
    await st.ref(`institutions/${INST_B}/courtDocuments/doc_b1/sealed.pdf`).put(samplePdf, { contentType: 'application/pdf' });
    await st.ref(`court_logos/${INST_A}/logo.png`).put(samplePng, { contentType: 'image/png' });
    await st.ref(`public_legal_repository/proc_1156/law.pdf`).put(samplePdf, { contentType: 'application/pdf' });
  });

  const unauthStorage = () => testEnv.unauthenticatedContext().storage();
  const anonStorage = () => testEnv.authenticatedContext('anon_1', { firebase: { sign_in_provider: 'anonymous' } }).storage();
  const verifiedNoRoleStorage = () => testEnv.authenticatedContext('user_1', { email: 'user1@example.org', email_verified: true, firebase: { sign_in_provider: 'password' } }).storage();
  const judgeAStorage = () => testEnv.authenticatedContext('judge_a1', { email: 'judge.a1@court.gov.et', email_verified: true, courtRole: 'judge', institutionId: INST_A, firebase: { sign_in_provider: 'password' } }).storage();
  const courtAdminAStorage = () => testEnv.authenticatedContext('cadmin_a1', { email: 'admin.a1@court.gov.et', email_verified: true, courtRole: 'court_admin', institutionId: INST_A, firebase: { sign_in_provider: 'password' } }).storage();
  const auditorAStorage = () => testEnv.authenticatedContext('aud_a1', { email: 'aud.a1@court.gov.et', email_verified: true, courtRole: 'auditor', institutionId: INST_A, firebase: { sign_in_provider: 'password' } }).storage();

  const results: StorageTestResult[] = [];
  const check = async (id: number, name: string, fn: () => Promise<void>) => {
    try {
      await fn();
      results.push({ id, name, passed: true });
      console.log(`PASS [${id}]: ${name}`);
    } catch (err: any) {
      results.push({ id, name, passed: false, detail: err?.message || String(err) });
      console.error(`FAIL [${id}]: ${name} -> ${err?.message || err}`);
    }
  };

  try {
    await check(1, 'Unauthenticated and anonymous users denied reading institutional court documents', async () => {
      await assertFails(unauthStorage().ref(`institutions/${INST_A}/courtDocuments/doc_a1/order.pdf`).getDownloadURL());
      await assertFails(anonStorage().ref(`institutions/${INST_A}/courtDocuments/doc_a1/order.pdf`).getDownloadURL());
    });

    await check(2, 'Verified user without institutional role denied reading institutional court documents', async () => {
      await assertFails(verifiedNoRoleStorage().ref(`institutions/${INST_A}/courtDocuments/doc_a1/order.pdf`).getDownloadURL());
    });

    await check(3, 'Authorized Institution A judge reads Institution A docs, denied reading Institution B docs', async () => {
      await assertSucceeds(judgeAStorage().ref(`institutions/${INST_A}/courtDocuments/doc_a1/order.pdf`).getDownloadURL());
      await assertFails(judgeAStorage().ref(`institutions/${INST_B}/courtDocuments/doc_b1/sealed.pdf`).getDownloadURL());
    });

    await check(4, 'Judge A uploads valid PDF with matching institutionId & uploadedBy metadata; auditor denied write', async () => {
      await assertSucceeds(
        judgeAStorage()
          .ref(`institutions/${INST_A}/courtDocuments/doc_a2/judgment.pdf`)
          .put(samplePdf, {
            contentType: 'application/pdf',
            customMetadata: {
              institutionId: INST_A,
              documentId: 'doc_a2',
              uploadedBy: 'judge_a1',
            },
          })
      );
      await assertFails(
        auditorAStorage()
          .ref(`institutions/${INST_A}/courtDocuments/doc_a3/tamper.pdf`)
          .put(samplePdf, {
            contentType: 'application/pdf',
            customMetadata: {
              institutionId: INST_A,
              documentId: 'doc_a3',
              uploadedBy: 'aud_a1',
            },
          })
      );
    });

    await check(5, 'Reject disallowed MIME types (executable/html) and oversized files (>50MB)', async () => {
      await assertFails(
        judgeAStorage()
          .ref(`institutions/${INST_A}/courtDocuments/doc_bad/payload.html`)
          .put(Buffer.from('<script>alert(1)</script>'), {
            contentType: 'text/html',
            customMetadata: {
              institutionId: INST_A,
              documentId: 'doc_bad',
              uploadedBy: 'judge_a1',
            },
          })
      );
      await assertFails(
        judgeAStorage()
          .ref(`institutions/${INST_A}/courtDocuments/doc_huge/huge.pdf`)
          .put(oversizedBuffer, {
            contentType: 'application/pdf',
            customMetadata: {
              institutionId: INST_A,
              documentId: 'doc_huge',
              uploadedBy: 'judge_a1',
            },
          })
      );
    });

    await check(6, 'Personal /legal_docs/personal_{uid}/{uid} scoped strictly to owner; cross-user denied', async () => {
      await assertSucceeds(
        verifiedNoRoleStorage()
          .ref('legal_docs/personal_user_1/user_1/brief.pdf')
          .put(samplePdf, { contentType: 'application/pdf' })
      );
      await assertFails(
        verifiedNoRoleStorage()
          .ref('legal_docs/personal_judge_a1/judge_a1/secret.pdf')
          .put(samplePdf, { contentType: 'application/pdf' })
      );
    });

    await check(7, 'Court logos allow public read, restrict upload/delete to verified institution court_admin', async () => {
      await assertSucceeds(unauthStorage().ref(`court_logos/${INST_A}/logo.png`).getDownloadURL());
      await assertSucceeds(courtAdminAStorage().ref(`court_logos/${INST_A}/seal.png`).put(samplePng, { contentType: 'image/png' }));
      await assertFails(judgeAStorage().ref(`court_logos/${INST_A}/seal2.png`).put(samplePng, { contentType: 'image/png' }));
      await assertFails(courtAdminAStorage().ref(`court_logos/${INST_B}/hijack.png`).put(samplePng, { contentType: 'image/png' }));
    });

    await check(8, 'Public legal repository allows read, restricts write to authorized legal managers; default deny unknown paths', async () => {
      await assertSucceeds(unauthStorage().ref('public_legal_repository/proc_1156/law.pdf').getDownloadURL());
      await assertFails(verifiedNoRoleStorage().ref('public_legal_repository/proc_1156/fake.pdf').put(samplePdf, { contentType: 'application/pdf' }));
      await assertFails(judgeAStorage().ref('arbitrary_unprotected/secret.pdf').put(samplePdf, { contentType: 'application/pdf' }));
    });
  } finally {
    await testEnv.cleanup();
  }

  const failed = results.filter((r) => !r.passed);
  console.log(`\nStorage Rules Emulator Suite: ${results.length - failed.length}/${results.length} passed`);
  if (failed.length > 0) {
    process.exit(1);
  }
}

runStorageRulesSuite().catch((err) => {
  console.error('Storage rules suite error:', err);
  process.exit(1);
});
