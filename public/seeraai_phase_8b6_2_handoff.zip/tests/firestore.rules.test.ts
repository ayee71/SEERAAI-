/**
 * SEERAAI PRO — Candidate Firestore Security Rules Verification Suite (Phase F / 8B.6.7)
 * Target Ruleset: firestore.rules.phase8b5.3.integrated.candidate
 * Target Project: demo-seeraai-test (isolated emulator only)
 *
 * Covers 21 positive & negative test scenarios against Firebase Emulator Suite.
 * Run with:
 *   firebase emulators:exec --config firebase.emulator.test.json --project demo-seeraai-test --only firestore "npx tsx tests/firestore.rules.test.ts"
 */
import fs from 'node:fs';
import path from 'node:path';

interface TestResult {
  id: number;
  name: string;
  passed: boolean;
  detail?: string;
}

async function runFirestoreRulesSuite(): Promise<void> {
  let testingModule: any;
  try {
    testingModule = await import('@firebase/rules-unit-testing' as string);
  } catch {
    console.error(
      'BLOCKED: @firebase/rules-unit-testing is not installed and Java JRE / Firebase Firestore Emulator is required.'
    );
    console.error(
      'Next step: Install Java JRE + devDependency @firebase/rules-unit-testing, then execute:\n  firebase emulators:exec --only firestore "npx tsx tests/firestore.rules.test.ts"'
    );
    process.exit(2);
  }

  const { initializeTestEnvironment, assertFails, assertSucceeds } = testingModule;
  const rulesPath = path.resolve(process.cwd(), 'firestore.rules.phase8b5.3.integrated.candidate');
  const rules = fs.readFileSync(rulesPath, 'utf8');

  const testEnv = await initializeTestEnvironment({
    projectId: 'demo-seeraai-test',
    firestore: {
      rules,
      host: '127.0.0.1',
      port: 8080,
    },
  });

  const INST_A = 'inst_oromia_high_court_a';
  const INST_B = 'inst_federal_high_court_b';

  await testEnv.withSecurityRulesDisabled(async (ctx: any) => {
    const db = ctx.firestore();
    await db.doc(`users/ordinary_u1`).set({ uid: 'ordinary_u1', role: 'user', email: 'u1@example.org', subscriptionTier: 'free' });
    await db.doc(`users/judge_a1`).set({ uid: 'judge_a1', role: 'judge', institutionId: INST_A, email: 'judge.a1@court.gov.et' });
    await db.doc(`court_institutions/${INST_A}`).set({ id: INST_A, name: 'East Shoa High Court', status: 'approved' });
    await db.doc(`court_institutions/${INST_B}`).set({ id: INST_B, name: 'Federal High Court B', status: 'approved' });
    await db.doc(`court_documents/doc_a1`).set({ id: 'doc_a1', institutionId: INST_A, createdBy: 'judge_a1', title: 'Ruling A1', isPublic: false });
    await db.doc(`court_documents/doc_b1`).set({ id: 'doc_b1', institutionId: INST_B, createdBy: 'judge_b1', title: 'Ruling B1', isPublic: false });
    await db.doc(`institutions/${INST_A}/courtDocuments/cd_a1`).set({ id: 'cd_a1', institutionId: INST_A, createdBy: 'judge_a1', title: 'Sealed Order A' });
    await db.doc(`institutions/${INST_B}/courtDocuments/cd_b1`).set({ id: 'cd_b1', institutionId: INST_B, createdBy: 'judge_b1', title: 'Sealed Order B' });
    await db.doc(`institutions/${INST_A}/auditLogs/log_a1`).set({ id: 'log_a1', actorUid: 'judge_a1', action: 'VIEW_CASE' });
    await db.doc(`cases/case_a1`).set({ id: 'case_a1', institutionId: INST_A, title: 'File 100/2026', isPublic: false });
    await db.doc(`cases/case_a1/audio_recordings/aud_1`).set({ id: 'aud_1', institutionId: INST_A, caseId: 'case_a1' });
    await db.doc(`witness_statements/ws_a1`).set({ id: 'ws_a1', institutionId: INST_A, witnessName: 'Witness A' });
    await db.doc(`witness_schedules/wsch_a1`).set({ id: 'wsch_a1', institutionId: INST_A, caseNumber: '100/2026' });
    await db.doc(`court_audio_recordings/car_a1`).set({ id: 'car_a1', institutionId: INST_A, caseId: 'case_a1' });
    await db.doc(`admin_activity_logs/adm_log_1`).set({ id: 'adm_log_1', action: 'CLAIMS_UPDATE', targetUid: 'judge_a1' });
    await db.doc(`telegram_logs/tlog_1`).set({ id: 'tlog_1', chatId: '99999', text: 'internal log' });
    await db.doc(`legislation_repository/proc_1156`).set({ id: 'proc_1156', title: 'Labor Proclamation 1156/2019' });
    await db.doc(`court_branding/${INST_A}`).set({ name: 'East Shoa High Court', logoUrl: 'https://example.org/logo.png' });
  });

  const ctxUnauth = () => testEnv.unauthenticatedContext().firestore();
  const ctxAnon = () => testEnv.authenticatedContext('anon_1', { firebase: { sign_in_provider: 'anonymous' } }).firestore();
  const ctxPhone = () => testEnv.authenticatedContext('phone_1', { phone_number: '+251911000000', email_verified: true, firebase: { sign_in_provider: 'phone' } }).firestore();
  const ctxOrdinary = () => testEnv.authenticatedContext('ordinary_u1', { email: 'u1@example.org', email_verified: false, firebase: { sign_in_provider: 'password' } }).firestore();
  const ctxVerifiedNoRole = () => testEnv.authenticatedContext('verified_norole', { email: 'public@example.org', email_verified: true, firebase: { sign_in_provider: 'password' } }).firestore();
  const ctxImpersonator = () => testEnv.authenticatedContext('impersonator', { email: 'ayeledha@gmail.com', email_verified: false, firebase: { sign_in_provider: 'password' } }).firestore();
  const ctxJudgeA = () => testEnv.authenticatedContext('judge_a1', { email: 'judge.a1@court.gov.et', email_verified: true, courtRole: 'judge', institutionId: INST_A, firebase: { sign_in_provider: 'password' } }).firestore();
  const ctxRegistrarA = () => testEnv.authenticatedContext('reg_a1', { email: 'reg.a1@court.gov.et', email_verified: true, courtRole: 'registrar', institutionId: INST_A, firebase: { sign_in_provider: 'password' } }).firestore();
  const ctxAssistantA = () => testEnv.authenticatedContext('asst_a1', { email: 'asst.a1@court.gov.et', email_verified: true, courtRole: 'assistant_judge', institutionId: INST_A, firebase: { sign_in_provider: 'password' } }).firestore();
  const ctxExpertA = () => testEnv.authenticatedContext('exp_a1', { email: 'exp.a1@court.gov.et', email_verified: true, courtRole: 'legal_expert', institutionId: INST_A, firebase: { sign_in_provider: 'password' } }).firestore();
  const ctxAuditorA = () => testEnv.authenticatedContext('aud_a1', { email: 'aud.a1@court.gov.et', email_verified: true, courtRole: 'auditor', institutionId: INST_A, firebase: { sign_in_provider: 'password' } }).firestore();
  const ctxCourtAdminA = () => testEnv.authenticatedContext('cadmin_a1', { email: 'cadmin.a1@court.gov.et', email_verified: true, courtRole: 'court_admin', institutionId: INST_A, firebase: { sign_in_provider: 'password' } }).firestore();
  const ctxAdmin = () => testEnv.authenticatedContext('super_admin_1', { email: 'admin@seeraai.et', email_verified: true, admin: true, role: 'superadmin', firebase: { sign_in_provider: 'password' } }).firestore();

  const results: TestResult[] = [];
  const check = async (id: number, name: string, fn: () => Promise<void>) => {
    try {
      await fn();
      results.push({ id, name, passed: true });
      console.log(`PASS [${id}]: ${name}`);
    } catch (err: any) {
      results.push({ id, name, passed: false, detail: err?.message || String(err) });
      console.error(`FAIL [${id}]: ${name} -> ${err?.message || err}`);
    }
  };

  try {
    await check(1, 'Unauthenticated user denied court docs/cases/admin logs; allowed public legislation', async () => {
      await assertFails(ctxUnauth().doc('court_documents/doc_a1').get());
      await assertFails(ctxUnauth().doc('cases/case_a1').get());
      await assertFails(ctxUnauth().doc('admin_activity_logs/adm_log_1').get());
      await assertSucceeds(ctxUnauth().doc('legislation_repository/proc_1156').get());
    });

    await check(2, 'Authenticated ordinary user reads own profile, denied others and court data', async () => {
      await assertSucceeds(ctxOrdinary().doc('users/ordinary_u1').get());
      await assertFails(ctxOrdinary().doc('users/judge_a1').get());
      await assertFails(ctxOrdinary().doc('court_documents/doc_a1').get());
      await assertFails(ctxOrdinary().doc('telegram_logs/tlog_1').get());
    });

    await check(3, 'Verified-email user without institutional role denied institutional staff resources', async () => {
      await assertFails(ctxVerifiedNoRole().doc(`institutions/${INST_A}/courtDocuments/cd_a1`).get());
      await assertFails(ctxVerifiedNoRole().doc('witness_schedules/wsch_a1').get());
      await assertFails(ctxVerifiedNoRole().doc('court_documents/doc_a1').get());
    });

    await check(4, 'Anonymous user denied profile creation, personal docs, and institutional data', async () => {
      await assertFails(ctxAnon().doc('users/anon_1').set({ uid: 'anon_1', role: 'user' }));
      await assertFails(ctxAnon().doc('legal_ai_audit/test_1').set({ uid: 'anon_1' }));
      await assertFails(ctxAnon().doc('witness_schedules/wsch_a1').get());
    });

    await check(5, 'Phone-authenticated user does not satisfy isEmailVerified() staff privileges', async () => {
      await assertFails(ctxPhone().doc('objection_templates/ot_1').set({ userId: 'phone_1', title: 'Test' }));
      await assertFails(ctxPhone().doc(`institutions/${INST_A}/courtDocuments/cd_a1`).get());
    });

    await check(6, 'Authorized judge reads & writes own institution court documents and cases', async () => {
      await assertSucceeds(ctxJudgeA().doc(`institutions/${INST_A}/courtDocuments/cd_a1`).get());
      await assertSucceeds(ctxJudgeA().doc('cases/case_a1').get());
      await assertSucceeds(
        ctxJudgeA().doc('court_documents/doc_a2').set({
          id: 'doc_a2',
          institutionId: INST_A,
          createdBy: 'judge_a1',
          title: 'Order A2',
          isPublic: false,
        })
      );
    });

    await check(7, 'Authorized registrar reads/writes institution A cases & schedules; denied institution B', async () => {
      await assertSucceeds(ctxRegistrarA().doc('cases/case_a1').update({ title: 'Updated Docket' }));
      await assertSucceeds(ctxRegistrarA().doc('witness_schedules/wsch_a2').set({ institutionId: INST_A, witness: 'W2' }));
      await assertFails(ctxRegistrarA().doc('cases/case_b1').get());
    });

    await check(8, 'Authorized assistant_judge accesses institution A dockets, denied admin activity logs', async () => {
      await assertSucceeds(ctxAssistantA().doc(`institutions/${INST_A}/courtDocuments/cd_a1`).get());
      await assertFails(ctxAssistantA().doc('admin_activity_logs/adm_log_1').get());
      await assertFails(ctxAssistantA().doc('admin_activity_logs/adm_log_asst').set({ actionType: 'config_update', target: 'test' }));
      await assertFails(ctxAssistantA().doc('admin_activity_logs/adm_log_1').update({ target: 'tampered' }));
      await assertFails(ctxAssistantA().doc('admin_activity_logs/adm_log_1').delete());
    });

    await check(9, 'Authorized legal_expert reads institution A legal docs & manages legal repository', async () => {
      await assertSucceeds(ctxExpertA().doc(`institutions/${INST_A}/courtDocuments/cd_a1`).get());
      await assertSucceeds(ctxExpertA().doc('legislation_repository/proc_new').set({ title: 'New Regulation' }));
      await assertFails(ctxExpertA().doc(`institutions/${INST_A}/courtDocuments/cd_a1`).delete());
    });

    await check(10, 'Authorized auditor reads institution A auditLogs, denied mutating or deleting audit logs', async () => {
      await assertSucceeds(ctxAuditorA().doc(`institutions/${INST_A}/auditLogs/log_a1`).get());
      await assertFails(ctxAuditorA().doc(`institutions/${INST_A}/auditLogs/log_a1`).update({ action: 'TAMPERED' }));
      await assertFails(ctxAuditorA().doc(`institutions/${INST_A}/auditLogs/log_a1`).delete());
    });

    await check(11, 'Authorized institution court_admin manages institution A branding, users, and doc deletion', async () => {
      await assertSucceeds(ctxCourtAdminA().doc(`court_branding/${INST_A}`).set({ name: 'Updated Court' }));
      await assertSucceeds(ctxCourtAdminA().doc('court_users/staff_new').set({ institutionId: INST_A, role: 'clerk' }));
      await assertFails(ctxCourtAdminA().doc('court_users/escalate').set({ institutionId: INST_A, role: 'superadmin' }));
    });

    await check(12, 'Unauthorized administrator impersonation attempt rejected', async () => {
      await assertFails(ctxImpersonator().doc('admin_activity_logs/adm_log_1').get());
      await assertFails(ctxImpersonator().doc('admin_activity_logs/adm_log_imp').set({ actionType: 'config_update', target: 'spoof' }));
      await assertFails(ctxImpersonator().doc('admin_activity_logs/adm_log_1').update({ target: 'tampered' }));
      await assertFails(ctxImpersonator().doc('admin_activity_logs/adm_log_1').delete());
      await assertFails(ctxImpersonator().doc('verifications/v1').get());
      await assertFails(ctxImpersonator().doc('users/ordinary_u1').get());
    });

    await check(13, 'Institution A user denied accessing Institution B documents', async () => {
      await assertFails(ctxJudgeA().doc(`institutions/${INST_B}/courtDocuments/cd_b1`).get());
      await assertFails(ctxJudgeA().doc('court_documents/doc_b1').get());
      await assertFails(ctxCourtAdminA().doc(`court_institutions/${INST_B}`).get());
    });

    await check(14, 'Institution A user denied updating document institutionId to Institution B', async () => {
      await assertFails(ctxJudgeA().doc('court_documents/doc_a1').update({ institutionId: INST_B }));
      await assertFails(ctxJudgeA().doc(`institutions/${INST_A}/courtDocuments/cd_a1`).update({ institutionId: INST_B }));
      await assertFails(ctxJudgeA().doc('cases/case_a1').update({ institutionId: INST_B }));
    });

    await check(15, 'Ordinary user denied changing their own role, admin, courtRole, or institutionId', async () => {
      await assertFails(ctxOrdinary().doc('users/ordinary_u1').update({ role: 'superadmin' }));
      await assertFails(ctxOrdinary().doc('users/ordinary_u1').update({ admin: true }));
      await assertFails(ctxOrdinary().doc('users/ordinary_u1').update({ courtRole: 'judge', institutionId: INST_A }));
      await assertSucceeds(ctxOrdinary().doc('users/ordinary_u1').update({ displayName: 'Abebe Bikila' }));
    });

    await check(16, 'Ordinary user denied reading, creating, updating, or deleting administrative & institutional audit logs', async () => {
      await assertFails(ctxOrdinary().doc('admin_activity_logs/adm_log_1').get());
      await assertFails(ctxOrdinary().doc('admin_activity_logs/adm_log_ord').set({ actionType: 'config_update', target: 'spoof' }));
      await assertFails(ctxOrdinary().doc('admin_activity_logs/adm_log_1').update({ target: 'tampered' }));
      await assertFails(ctxOrdinary().doc('admin_activity_logs/adm_log_1').delete());
      await assertFails(ctxOrdinary().doc(`institutions/${INST_A}/auditLogs/log_a1`).get());
    });

    await check(17, 'Unauthorized user denied reading witness statements and schedules', async () => {
      await assertFails(ctxOrdinary().doc('witness_statements/ws_a1').get());
      await assertFails(ctxVerifiedNoRole().doc('witness_schedules/wsch_a1').get());
    });

    await check(18, 'Unauthorized user denied reading courtroom audio recordings', async () => {
      await assertFails(ctxOrdinary().doc('court_audio_recordings/car_a1').get());
      await assertFails(ctxVerifiedNoRole().doc('cases/case_a1/audio_recordings/aud_1').get());
    });

    await check(19, 'Unauthorized user denied accessing sealed court documents or injecting >64KB base64 dataUrl', async () => {
      await assertFails(ctxVerifiedNoRole().doc(`institutions/${INST_A}/courtDocuments/cd_a1`).get());
      const oversizedPayload = 'A'.repeat(70000);
      await assertFails(
        ctxJudgeA().doc('court_documents/doc_oversized').set({
          institutionId: INST_A,
          createdBy: 'judge_a1',
          dataUrl: oversizedPayload,
        })
      );
    });

    await check(20, 'Authorized users perform legitimate audit creation, witness read, and public branding read', async () => {
      await assertSucceeds(ctxUnauth().doc(`court_branding/${INST_A}`).get());
      await assertSucceeds(ctxJudgeA().doc('witness_statements/ws_a1').get());
      await assertSucceeds(ctxJudgeA().doc('court_audio_recordings/car_a1').get());
      await assertSucceeds(
        ctxJudgeA().doc(`institutions/${INST_A}/auditLogs/log_new`).set({
          actorUid: 'judge_a1',
          action: 'DOWNLOAD_RECORD',
        })
      );
    });

    await check(21, 'Verified admin can read/create admin_activity_logs, but update/delete remain denied for immutability', async () => {
      await assertSucceeds(ctxAdmin().doc('admin_activity_logs/adm_log_1').get());
      await assertSucceeds(ctxAdmin().doc('admin_activity_logs/adm_log_2').set({ actionType: 'security_policy_change', target: 'rules', details: 'Verified admin log' }));
      await assertFails(ctxAdmin().doc('admin_activity_logs/adm_log_1').update({ target: 'tampered' }));
      await assertFails(ctxAdmin().doc('admin_activity_logs/adm_log_1').delete());
    });
  } finally {
    await testEnv.cleanup();
  }

  const failed = results.filter((r) => !r.passed);
  console.log(`\nFirestore Rules Emulator Suite: ${results.length - failed.length}/${results.length} passed`);
  if (failed.length > 0) {
    process.exit(1);
  }
}

runFirestoreRulesSuite().catch((err) => {
  console.error('Firestore rules suite error:', err);
  process.exit(1);
});
