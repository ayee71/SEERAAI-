import { createHash } from 'node:crypto';
import path from 'node:path';
import { FieldValue, type Firestore } from 'firebase-admin/firestore';
import type { Bucket, File as GcsFile } from '@google-cloud/storage';
import type {
  LegalContentDependencies,
  LegalDocumentRevisionInput,
  ParsedTelegramLegalContent,
  StoreLegalContentResult,
} from './types.js';

const DEFAULT_MAX_FILE_BYTES = 25 * 1024 * 1024;
const TEXT_CHUNK_SIZE = 6_000;
const FIRESTORE_BATCH_LIMIT = 450;

const ALLOWED_MIME_BY_EXTENSION: Record<string, string> = {
  '.pdf': 'application/pdf',
  '.doc': 'application/msword',
  '.docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
};

function sanitizeFileName(fileName: string): string {
  const baseName = path.basename(fileName || 'legal-document');
  const safe = baseName
    .normalize('NFKC')
    .replace(/[^\p{L}\p{N}._-]+/gu, '_')
    .replace(/^\.+/, '')
    .slice(0, 140);
  return safe || 'legal-document';
}

function validateDocument(input: Pick<ParsedTelegramLegalContent,
  'fileName' | 'mimeType' | 'fileBuffer' | 'extractedText'>,
  maxFileBytes: number,
): void {
  if (!input.fileBuffer?.length) throw new Error('Faayilli duwwaa taʼe fudhatamuu hin dandaʼu.');
  if (input.fileBuffer.length > maxFileBytes) {
    throw new Error(`Hammi faayilaa daangaa ${Math.floor(maxFileBytes / 1024 / 1024)} MB caaleera.`);
  }
  if (!input.extractedText?.trim()) {
    throw new Error('Barreeffamni faayila keessaa hin baane. OCR ykn text extraction sirreessaa.');
  }
  const extension = path.extname(input.fileName).toLowerCase();
  const expectedMime = ALLOWED_MIME_BY_EXTENSION[extension];
  if (!expectedMime) throw new Error('PDF, DOC ykn DOCX qofatu hayyamama.');
  if (input.mimeType !== expectedMime) {
    throw new Error(`MIME type faayilaa extension waliin hin walsimu (${extension}).`);
  }
}

function makeStoragePath(documentId: string, fileName: string): string {
  return `legal-library/${documentId}/original/${sanitizeFileName(fileName)}`;
}

async function savePrivateFile(
  bucket: Bucket,
  objectPath: string,
  data: Buffer,
  contentType: string,
  customMetadata: Record<string, string>,
): Promise<GcsFile> {
  const file = bucket.file(objectPath);
  await file.save(data, {
    resumable: false,
    validation: 'crc32c',
    metadata: {
      contentType,
      cacheControl: 'private, no-store',
      metadata: customMetadata,
    },
  });
  return file;
}

async function writeTextChunks(
  db: Firestore,
  documentId: string,
  text: string,
): Promise<number> {
  const chunks: string[] = [];
  for (let offset = 0; offset < text.length; offset += TEXT_CHUNK_SIZE) {
    chunks.push(text.slice(offset, offset + TEXT_CHUNK_SIZE));
  }

  const chunksRef = db.collection('legalDocuments').doc(documentId).collection('textChunks');
  for (let start = 0; start < chunks.length; start += FIRESTORE_BATCH_LIMIT) {
    const batch = db.batch();
    chunks.slice(start, start + FIRESTORE_BATCH_LIMIT).forEach((chunk, index) => {
      const chunkNumber = start + index;
      batch.set(chunksRef.doc(String(chunkNumber).padStart(6, '0')), {
        chunkNumber,
        text: chunk,
        createdAt: FieldValue.serverTimestamp(),
      });
    });
    await batch.commit();
  }
  return chunks.length;
}

/**
 * Store the original file in Cloud Storage and searchable text in bounded Firestore chunks.
 * The original document is never overwritten by an edit.
 */
export async function storeTelegramLegalContentInFirestore(
  docData: ParsedTelegramLegalContent,
  deps: LegalContentDependencies,
): Promise<StoreLegalContentResult> {
  const maxFileBytes = deps.maxFileBytes ?? DEFAULT_MAX_FILE_BYTES;
  validateDocument(docData, maxFileBytes);

  const sha256 = createHash('sha256').update(docData.fileBuffer).digest('hex');
  const documentId = sha256;
  const documentRef = deps.db.collection('legalDocuments').doc(documentId);
  const existing = await documentRef.get();

  if (existing.exists) {
    await documentRef.update({
      sourceImports: FieldValue.arrayUnion({
        ...docData.source,
        importedAt: docData.source.importedAt ?? new Date().toISOString(),
      }),
      updatedAt: FieldValue.serverTimestamp(),
    });
    return {
      success: true,
      firestoreId: documentId,
      duplicate: true,
      searchIndexed: existing.get('searchIndexed') === true,
      message: 'Faayilli kun duraan kuufameera; madda galchuu haaraa qofa itti dabaleera.',
    };
  }

  const safeFileName = sanitizeFileName(docData.fileName);
  const originalStoragePath = makeStoragePath(documentId, safeFileName);
  const textStoragePath = `legal-library/${documentId}/extracted/extracted.txt`;
  const sourceImport = {
    ...docData.source,
    importedAt: docData.source.importedAt ?? new Date().toISOString(),
  };

  // Content-addressed paths make concurrent duplicate uploads harmless: identical bytes share one object path.
  await savePrivateFile(deps.bucket, originalStoragePath, docData.fileBuffer, docData.mimeType, {
    sha256,
    documentId,
    role: 'original',
  });
  await savePrivateFile(deps.bucket, textStoragePath, Buffer.from(docData.extractedText, 'utf8'), 'text/plain; charset=utf-8', {
    sha256,
    documentId,
    role: 'extracted-text',
  });

  const metadata = {
    title: docData.title.trim().slice(0, 300),
    fileName: safeFileName,
    mimeType: docData.mimeType,
    fileSize: docData.fileBuffer.length,
    sha256,
    originalStoragePath,
    extractedTextStoragePath: textStoragePath,
    extractedTextLength: docData.extractedText.length,
    sourceImports: [sourceImport],
    uploadedBy: docData.uploadedBy,
    language: docData.language ?? 'unknown',
    caseNumber: docData.caseNumber ?? null,
    volume: docData.volume ?? null,
    decisionYear: docData.decisionYear ?? null,
    court: docData.court ?? null,
    tags: (docData.tags ?? []).slice(0, 30),
    reviewStatus: docData.reviewStatus ?? 'pending_review',
    revisionCount: 0,
    searchIndexed: false,
    status: 'stored',
    createdAt: FieldValue.serverTimestamp(),
    updatedAt: FieldValue.serverTimestamp(),
  };

  try {
    // create() prevents silently replacing an existing document with the same content hash.
    await documentRef.create(metadata);
  } catch (error) {
    const code = (error as { code?: number | string })?.code;
    if (code === 6 || code === 'already-exists' || code === 'ALREADY_EXISTS') {
      await documentRef.update({
        sourceImports: FieldValue.arrayUnion(sourceImport),
        updatedAt: FieldValue.serverTimestamp(),
      });
      return {
        success: true,
        firestoreId: documentId,
        duplicate: true,
        message: 'Faayilli kun yeroo tokko biraa galfameera; madda haaraa itti dabaleera.',
      };
    }
    throw error;
  }

  let searchIndexed = false;
  let indexingMessage = '';
  try {
    const chunkCount = await writeTextChunks(deps.db, documentId, docData.extractedText);
    if (deps.indexLegalContent) {
      await deps.indexLegalContent({
        id: documentId,
        title: metadata.title,
        text: docData.extractedText,
        metadata: {
          caseNumber: metadata.caseNumber,
          volume: metadata.volume,
          decisionYear: metadata.decisionYear,
          court: metadata.court,
          language: metadata.language,
          reviewStatus: metadata.reviewStatus,
          sourceKind: docData.source.kind,
        },
      });
      searchIndexed = true;
    }
    await documentRef.update({
      textChunkCount: chunkCount,
      searchIndexed,
      status: 'stored',
      updatedAt: FieldValue.serverTimestamp(),
    });
  } catch (error) {
    indexingMessage = error instanceof Error ? error.message : 'Sababa hin beekamne';
    await documentRef.update({
      searchIndexed: false,
      indexingError: indexingMessage.slice(0, 500),
      status: 'stored_indexing_failed',
      updatedAt: FieldValue.serverTimestamp(),
    });
  }

  return {
    success: true,
    firestoreId: documentId,
    duplicate: false,
    searchIndexed,
    message: searchIndexed
      ? 'Faayilli fi barruun isaa kuufame; search index keessattis galmaaʼeera.'
      : `Faayilli kuufameera. Search index ammallee hin milkoofne${indexingMessage ? `: ${indexingMessage}` : '; indexer hin kennamne'}.`,
  };
}

/** Save edits as a new immutable version. The imported original remains unchanged. */
export async function saveLegalDocumentRevision(
  input: LegalDocumentRevisionInput,
  deps: Pick<LegalContentDependencies, 'db' | 'bucket' | 'maxFileBytes' | 'indexLegalContent'>,
): Promise<{ success: boolean; versionId: string; versionNumber: number; message: string }> {
  validateDocument(input, deps.maxFileBytes ?? DEFAULT_MAX_FILE_BYTES);
  if (!input.changeNote.trim()) throw new Error('Gulaallii kanaaf ibsa gabaabaa galchi.');

  const documentRef = deps.db.collection('legalDocuments').doc(input.documentId);
  const versionRef = documentRef.collection('versions').doc();
  const sha256 = createHash('sha256').update(input.fileBuffer).digest('hex');

  const versionNumber = await deps.db.runTransaction(async (tx) => {
    const parent = await tx.get(documentRef);
    if (!parent.exists) throw new Error('Galmeen seeraa kun hin jiru.');
    const nextVersion = Number(parent.get('revisionCount') ?? 0) + 1;
    tx.update(documentRef, {
      revisionCount: nextVersion,
      updatedAt: FieldValue.serverTimestamp(),
    });
    tx.create(versionRef, {
      versionNumber: nextVersion,
      editorUid: input.editorUid,
      changeNote: input.changeNote.trim().slice(0, 1_000),
      fileName: sanitizeFileName(input.fileName),
      mimeType: input.mimeType,
      sha256,
      status: 'processing',
      createdAt: FieldValue.serverTimestamp(),
    });
    return nextVersion;
  });

  const basePath = `legal-library/${input.documentId}/versions/v${versionNumber}`;
  const filePath = `${basePath}/${sanitizeFileName(input.fileName)}`;
  const textPath = `${basePath}/extracted.txt`;

  try {
    await savePrivateFile(deps.bucket, filePath, input.fileBuffer, input.mimeType, {
      documentId: input.documentId,
      versionNumber: String(versionNumber),
      sha256,
      role: 'revision',
    });
    await savePrivateFile(deps.bucket, textPath, Buffer.from(input.extractedText, 'utf8'), 'text/plain; charset=utf-8', {
      documentId: input.documentId,
      versionNumber: String(versionNumber),
      role: 'revision-text',
    });
    await versionRef.update({
      status: 'saved',
      storagePath: filePath,
      extractedTextStoragePath: textPath,
      extractedTextLength: input.extractedText.length,
    });
    await documentRef.update({
      latestVersion: versionNumber,
      updatedAt: FieldValue.serverTimestamp(),
    });

    if (deps.indexLegalContent) {
      try {
        await deps.indexLegalContent({
          id: `${input.documentId}_v${versionNumber}`,
          title: input.fileName,
          text: input.extractedText,
          metadata: { documentId: input.documentId, versionNumber, editorUid: input.editorUid },
        });
      } catch (indexError) {
        await versionRef.update({
          searchIndexed: false,
          indexingError: (indexError instanceof Error ? indexError.message : 'Index failed').slice(0, 500),
        });
      }
    }
  } catch (error) {
    await versionRef.update({
      status: 'failed',
      errorMessage: (error instanceof Error ? error.message : 'Unknown error').slice(0, 500),
    });
    throw error;
  }

  return {
    success: true,
    versionId: versionRef.id,
    versionNumber,
    message: `Gulaalliin version ${versionNumber} taʼee haala adda taʼeen kuufameera. Faayilli jalqabaa hin jijjiiramne.`,
  };
}

/** Optional helper for authorized backend cleanup jobs only. */
export async function readExtractedTextFromStorage(
  bucket: Bucket,
  storagePath: string,
): Promise<string> {
  const [contents] = await bucket.file(storagePath).download();
  return contents.toString('utf8');
}

export type LegalContentServiceDb = Firestore;
