export type LegalLanguage = 'om' | 'am' | 'en';
export type LegalJurisdiction = 'federal' | 'oromia' | 'both' | 'unknown';

export interface LegalAnswerRequest {
  question: string;
  language: LegalLanguage; // Pass the app's current selected language.
  jurisdiction?: LegalJurisdiction;
  relevantDate?: string;
  facts?: string;
  compareJurisdictions?: boolean;
}

export interface LegalCitation {
  sourceRef: string;
  title: string;
  sourceType: string;
  jurisdiction: 'federal' | 'oromia';
  issuingInstitution: string;
  proclamationNumber?: string;
  decisionNumber?: string;
  volume?: string;
  page?: string;
  articleNumbers?: string[];
  effectiveDate?: string;
  repealDate?: string;
  officialSourceName?: string;
  officialSourceUrl?: string;
  documentStoragePath?: string;
}

export interface TelegramResearchLead {
  candidateId: string;
  channelTitle: string;
  messageId: number;
  messageDate?: string;
  messageText: string;
  permalink?: string;
  reviewStatus: 'PENDING_REVIEW';
  sourceStatus: 'UNVERIFIED_TELEGRAM_LEAD';
}

export interface LegalAnswerResponse {
  ok: boolean;
  requestId: string;
  language: LegalLanguage;
  jurisdiction: LegalJurisdiction;
  relevantDate: string;
  verification: 'SOURCE_GROUNDED' | 'INSUFFICIENT_SOURCES' | 'AI_ERROR';
  analysis?: {
    directAnswer: string;
    legalRules: Array<{ sourceRef: string; instrumentTitle: string; provisions: string[]; rule: string; application: string }>;
    comparativeAnalysis: { available: boolean; federalPosition: string; oromiaPosition: string; similarities: string[]; differences: string[]; competenceAndHierarchy: string; sourceRefs: string[] };
    cassationAnalysis: Array<{ sourceRef: string; court: string; decisionNumber: string; volume?: string; page?: string; legalIssue: string; holding: string; factualSimilarity: string }>;
    factualApplication: string;
    conclusion: string;
    limitations: string[];
    furtherFactsNeeded: string[];
  };
  citations: LegalCitation[];
  researchLeads: TelegramResearchLead[];
  warnings: string[];
  disclaimer: string;
  provider?: 'openai' | 'gemini';
}
