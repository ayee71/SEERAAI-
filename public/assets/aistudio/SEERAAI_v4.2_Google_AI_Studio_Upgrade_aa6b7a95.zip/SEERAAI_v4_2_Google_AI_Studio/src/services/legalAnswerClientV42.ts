import { getAuth } from 'firebase/auth';
import type { LegalAnswerRequest, LegalAnswerResponse } from '../types/legalAnswerV42';

export async function askSEERAAIV42(input: LegalAnswerRequest): Promise<LegalAnswerResponse> {
  const user = getAuth().currentUser;
  if (!user) throw new Error('Authentication required.');
  const token = await user.getIdToken();
  const response = await fetch('/api/legal/ask', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
    body: JSON.stringify(input),
  });
  const payload = await response.json().catch(() => null);
  if (!response.ok) {
    const code = payload?.error ?? `HTTP_${response.status}`;
    throw new Error(`SEERAAI request failed: ${code}`);
  }
  return payload as LegalAnswerResponse;
}
