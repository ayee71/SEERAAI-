import type { Firestore } from 'firebase-admin/firestore';
import type {
  LegalAnswerRequest, LegalAnswerResponse, LegalCitation, LegalJurisdiction,
  LegalRuleAnalysis, CassationAnalysis, RetrievedLegalSource,
} from './types';
import { detectLanguage, isIsoDate } from './queryTools';
import { retrieveLegalSources } from './legalSearch';
import { searchTelegramCassation } from './telegramSearch';
import { buildAnalysisPrompt } from './analysisPrompt';
import { generateLegalAnalysis, languageFallback } from './aiProvider';

function normalizeJurisdiction(value?: LegalJurisdiction): LegalJurisdiction {
  return value === 'federal' || value === 'oromia' || value === 'both' ? value : 'both';
}

function makeCitation(source: RetrievedLegalSource): LegalCitation {
  return {
    sourceRef: source.sourceRef,
    title: source.title,
    sourceType: source.sourceType,
    jurisdiction: source.jurisdiction,
    issuingInstitution: source.issuingInstitution,
    proclamationNumber: source.proclamationNumber,
    decisionNumber: source.decisionNumber,
    volume: source.volume,
    page: source.page,
    articleNumbers: source.articleNumbers,
    effectiveDate: source.effectiveDate,
    repealDate: source.repealDate,
    officialSourceName: source.officialSourceName,
    officialSourceUrl: source.officialSourceUrl,
    documentStoragePath: source.documentStoragePath,
  };
}

function filterAnalysisToRetrievedSources(
  analysis: Awaited<ReturnType<typeof generateLegalAnalysis>>['analysis'],
  sources: RetrievedLegalSource[],
  compare: boolean,
): { analysis: typeof analysis; usedRefs: Set<string>; warnings: string[] } {
  const byRef = new Map(sources.map((source) => [source.sourceRef, source]));
  const warnings: string[] = [];
  const validRules: LegalRuleAnalysis[] = analysis.legalRules.flatMap((item) => {
    const source = byRef.get(item.sourceRef);
    if (!source || source.sourceType === 'cassation_decision') return [];
    // Never trust model-generated instrument names or article numbers as metadata.
    return [{ ...item, instrumentTitle: source.title, provisions: source.articleNumbers ?? [] }];
  });
  const validCases: CassationAnalysis[] = analysis.cassationAnalysis.flatMap((item) => {
    const source = byRef.get(item.sourceRef);
    if (!source || source.sourceType !== 'cassation_decision') return [];
    // Court, decision number, volume and page always come from the verified record.
    return [{
      ...item,
      court: source.issuingInstitution,
      decisionNumber: source.decisionNumber ?? '',
      volume: source.volume,
      page: source.page,
    }];
  });
  const federal = sources.some((source) => source.jurisdiction === 'federal');
  const oromia = sources.some((source) => source.jurisdiction === 'oromia');
  const canCompare = compare && federal && oromia;
  if (compare && !canCompare) {
    warnings.push('Federal–Oromia comparison is incomplete: verified and relevant sources from both jurisdictions were not retrieved.');
  }
  if (analysis.legalRules.length !== validRules.length || analysis.cassationAnalysis.length !== validCases.length) {
    warnings.push('One or more AI-generated source references did not match the retrieved verified source set and were removed.');
  }
  const compareRefs = canCompare
    ? analysis.comparativeAnalysis.sourceRefs.filter((ref) => byRef.has(ref))
    : [];
  const compareHasFederal = compareRefs.some((ref) => byRef.get(ref)?.jurisdiction === 'federal');
  const compareHasOromia = compareRefs.some((ref) => byRef.get(ref)?.jurisdiction === 'oromia');
  const comparisonIsActuallyGrounded = canCompare && compareHasFederal && compareHasOromia;
  if (canCompare && !comparisonIsActuallyGrounded) {
    warnings.push('The AI did not cite verified sources from both jurisdictions in its comparison; the comparative conclusion has been disabled.');
  }
  const safeAnalysis = {
    ...analysis,
    legalRules: validRules,
    cassationAnalysis: validCases,
    comparativeAnalysis: {
      ...analysis.comparativeAnalysis,
      available: comparisonIsActuallyGrounded,
      sourceRefs: comparisonIsActuallyGrounded ? compareRefs : [],
      ...(!comparisonIsActuallyGrounded ? {
        federalPosition: federal ? analysis.comparativeAnalysis.federalPosition : 'No sufficiently verified Federal source was retrieved.',
        oromiaPosition: oromia ? analysis.comparativeAnalysis.oromiaPosition : 'No sufficiently verified Oromia source was retrieved.',
        similarities: [],
        differences: [],
        competenceAndHierarchy: 'Cannot be concluded without verified legal texts from both jurisdictions and analysis of the relevant constitutional competence.',
      } : {}),
    },
  };
  const usedRefs = new Set<string>();
  validRules.forEach((item) => usedRefs.add(item.sourceRef));
  validCases.forEach((item) => usedRefs.add(item.sourceRef));
  if (comparisonIsActuallyGrounded) compareRefs.forEach((ref) => usedRefs.add(ref));
  return { analysis: safeAnalysis, usedRefs, warnings };
}

export async function answerLegalQuestion(
  db: Firestore,
  input: LegalAnswerRequest,
  requestId: string,
): Promise<LegalAnswerResponse> {
  const question = input.question.trim().slice(0, 8000);
  const facts = (input.facts ?? '').trim().slice(0, 12000);
  const language = detectLanguage(question, input.language);
  const jurisdiction = normalizeJurisdiction(input.jurisdiction);
  const warnings: string[] = [];
  if (input.relevantDate && !isIsoDate(input.relevantDate)) {
    return {
      ok: false, requestId, language, jurisdiction,
      relevantDate: input.relevantDate,
      verification: 'INSUFFICIENT_SOURCES', citations: [], researchLeads: [],
      warnings: ['Invalid relevantDate; use a real Gregorian date in YYYY-MM-DD format.'],
      disclaimer: "Guyyaa seeraa sirrii galchi; seera guyyaa dogoggoraa irratti hundaa\'uun hin danda\'amu.",
    };
  }
  const relevantDate = input.relevantDate ?? new Date().toISOString().slice(0, 10);

  if (question.length < 4) {
    return {
      ok: false, requestId, language, jurisdiction, relevantDate,
      verification: 'INSUFFICIENT_SOURCES', citations: [], researchLeads: [],
      warnings: ['The question is too short.'],
      disclaimer: 'Qorannoo seeraa qofaaf. Deebiin AI murtii mana murtii bakka hin bu’u.',
    };
  }

  // Telegram is searched independently. Its results stay outside the AI authority set
  // until an authorized human reviewer authenticates the original decision.
  const [sources, telegram] = await Promise.all([
    retrieveLegalSources({ db, question, facts, jurisdiction, relevantDate, maxSources: 24 }),
    searchTelegramCassation({ db, question, facts }),
  ]);
  if (telegram.warning) warnings.push(telegram.warning);

  if (!sources.length) {
    return {
      ok: true, requestId, language, jurisdiction, relevantDate,
      verification: 'INSUFFICIENT_SOURCES', citations: [], researchLeads: telegram.candidates,
      warnings: [...warnings, 'No sufficiently relevant, provenance-verified legal record was retrieved from Firestore. Telegram hits, if any, are unverified leads and cannot support a legal conclusion.'],
      disclaimer: 'Deebiin kun qorannoo seeraa qofaaf. Murtiiwwan Telegram irratti argaman hanga madda jalqabaa irraa mirkanaa’anii hayyama qabuun galmaa’anitti wabii seeraa miti.',
    };
  }

  const prompt = buildAnalysisPrompt({
    ...input,
    question,
    facts,
    language,
    jurisdiction,
    compareJurisdictions: input.compareJurisdictions !== false,
  }, relevantDate, sources);

  try {
    const generated = await generateLegalAnalysis(prompt);
    const filtered = filterAnalysisToRetrievedSources(
      generated.analysis,
      sources,
      input.compareJurisdictions !== false && (jurisdiction === 'both' || jurisdiction === 'unknown'),
    );
    warnings.push(...filtered.warnings);
    const citations = sources.filter((source) => filtered.usedRefs.has(source.sourceRef)).map(makeCitation);
    if (citations.length === 0) {
      return {
        ok: true, requestId, language, jurisdiction, relevantDate,
        verification: 'INSUFFICIENT_SOURCES', citations: [], researchLeads: telegram.candidates,
        warnings: [...warnings, languageFallback(language)],
        disclaimer: 'Deebiin kun qorannoo seeraa qofaaf; madda mirkanaa’e malee xumura seeraa hin kennu.',
        provider: generated.provider,
      };
    }
    const temporalWarnings = sources.filter((source) => source.dateWarning).map((source) => `${source.title}: ${source.dateWarning}`);
    warnings.push(...temporalWarnings);
    return {
      ok: true,
      requestId,
      language,
      jurisdiction,
      relevantDate,
      verification: 'SOURCE_GROUNDED',
      analysis: filtered.analysis,
      citations,
      researchLeads: telegram.candidates,
      warnings,
      disclaimer: language === 'en'
        ? 'Legal research support only; not a judicial decision. Verify the original legal text and case file before relying on this output.'
        : language === 'am'
          ? 'ይህ ለሕግ ምርምር የሚረዳ መረጃ ብቻ ነው፤ የፍርድ ቤት ውሳኔ አይደለም። ዋናውን የሕግ ሰነድና የፍርድ መዝገብ ያረጋግጡ።'
          : 'Deebiin kun qorannoo seeraa deeggaruuf qofa; murtii mana murtii miti. Sanada seeraa fi galmee murtii madda jalqabaa irraa mirkaneessi.',
      provider: generated.provider,
    };
  } catch (error) {
    warnings.push(error instanceof Error ? error.message : 'Legal analysis provider failed.');
    return {
      ok: false, requestId, language, jurisdiction, relevantDate,
      verification: 'AI_ERROR', citations: [], researchLeads: telegram.candidates,
      warnings,
      disclaimer: 'Tajaajilli AI yeroo ammaa deebii qopheessuu hin dandeenye. Maddoonni Telegram argaman garuu hanga mirkanaa’anitti wabii seeraa miti.',
    };
  }
}
