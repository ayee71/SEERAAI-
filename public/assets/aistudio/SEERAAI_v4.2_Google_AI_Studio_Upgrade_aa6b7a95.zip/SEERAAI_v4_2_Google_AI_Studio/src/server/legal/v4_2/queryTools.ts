import type { LegalLanguage } from './types';

const STOP_WORDS = new Set([
  'the', 'and', 'for', 'with', 'from', 'that', 'this', 'what', 'when',
  'where', 'which', 'who', 'how', 'can', 'may', 'does', 'into', 'are',
  'akka', 'maal', 'maaliif', 'eessa', 'yoom', 'eenyu', 'akkam', 'irra',
  'fi', 'kan', 'kun', 'sun', 'maaloo', 'በ', 'እና', 'ወይም', 'ምን',
  'እንዴት', 'ለምን', 'ከ', 'የ', 'ላይ',
]);

// Curated concept expansion only. These are search hints, never legal authority.
const CONCEPTS: Record<string, string[]> = {
  inheritance: ['dhaaltummaa', 'inheritance', 'succession', 'ውርስ'],
  dhaaltummaa: ['inheritance', 'succession', 'ውርስ'],
  ውርስ: ['inheritance', 'dhaaltummaa'],
  lease: ['kiraa', 'rent', 'tenancy', 'ኪራይ'],
  kiraa: ['lease', 'rent', 'tenancy', 'ኪራይ'],
  land: ['lafa', 'landholding', 'የመሬት'],
  lafa: ['land', 'landholding', 'የመሬት'],
  evidence: ['ragaa', 'proof', 'ማስረጃ'],
  ragaa: ['evidence', 'proof', 'ማስረጃ'],
  contract: ['waliigaltee', 'agreement', 'ውል'],
  waliigaltee: ['contract', 'agreement', 'ውል'],
  jurisdiction: ['aangoo', 'competence', 'ሥልጣን'],
  aangoo: ['jurisdiction', 'competence', 'ሥልጣን'],
  employment: ['hojii', 'labour', 'labor', 'የሥራ'],
  hojii: ['employment', 'labour', 'labor', 'የሥራ'],
  marriage: ['gaaela', 'fuudhaa', 'የጋብቻ'],
  criminal: ['yakka', 'crime', 'ወንጀል'],
  yakka: ['criminal', 'crime', 'ወንጀል'],
  civil: ['hariiroo hawaasaa', 'civil procedure', 'ፍትሐብሔር'],
};

export function normalizeForSearch(value: string): string {
  return value
    .normalize('NFKC')
    .toLocaleLowerCase()
    .replace(/[’‘`]/g, "'")
    .replace(/[^\p{L}\p{N}\s/-]/gu, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

export function extractSearchTokens(value: string, max = 10): string[] {
  const rawTokens = normalizeForSearch(value)
    .split(' ')
    .map((token) => token.trim())
    .filter((token) => token.length >= 2 && !STOP_WORDS.has(token));
  const tokens = new Set<string>(rawTokens);
  // Common attached Amharic grammatical prefixes are separated for retrieval.
  // Keep the original word too: this is query expansion, not text rewriting.
  for (const token of rawTokens) {
    for (const prefix of ['የ', 'በ', 'ለ', 'ከ', 'ወደ', 'ስለ']) {
      if (token.startsWith(prefix) && token.length - prefix.length >= 2) {
        const remainder = token.slice(prefix.length);
        if (!STOP_WORDS.has(remainder)) tokens.add(remainder);
      }
    }
  }
  return [...tokens].slice(0, Math.max(1, Math.min(max, 10)));
}

export function expandSearchTerms(value: string, max = 10): string[] {
  const base = extractSearchTokens(value, 10);
  const expanded = new Set<string>(base);
  for (const token of base) {
    for (const related of CONCEPTS[token] ?? []) {
      for (const item of extractSearchTokens(related, 5)) expanded.add(item);
    }
  }
  return [...expanded].slice(0, Math.max(1, Math.min(max, 10)));
}


export function buildIndexTokens(value: string, max = 100): string[] {
  const base = normalizeForSearch(value).split(' ').filter((token) => token.length >= 2 && !STOP_WORDS.has(token));
  const tokens = new Set<string>(base);
  for (const token of base) {
    for (const prefix of ['የ', 'በ', 'ለ', 'ከ', 'ወደ', 'ስለ']) {
      if (token.startsWith(prefix) && token.length - prefix.length >= 2) tokens.add(token.slice(prefix.length));
    }
    for (const related of CONCEPTS[token] ?? []) {
      for (const item of normalizeForSearch(related).split(' ').filter((part) => part.length >= 2)) tokens.add(item);
    }
  }
  return [...tokens].slice(0, Math.max(1, Math.min(max, 200)));
}

export function detectLanguage(text: string, requested?: LegalLanguage): LegalLanguage {
  if (requested) return requested;
  if (/[\u1200-\u137F]/u.test(text)) return 'am';
  // Oromo and English both use Latin script: do not pretend that script detection
  // can reliably distinguish them. The UI should send its selected language.
  return 'om';
}

export function isStatuteApplicableOnDate(
  source: { effectiveDate?: string; repealDate?: string },
  date: string,
): { applicable: boolean; warning?: string } {
  const target = Date.parse(`${date}T00:00:00.000Z`);
  if (!Number.isFinite(target)) return { applicable: false, warning: 'Invalid relevant date.' };
  const start = source.effectiveDate ? Date.parse(`${source.effectiveDate.slice(0, 10)}T00:00:00.000Z`) : NaN;
  const end = source.repealDate ? Date.parse(`${source.repealDate.slice(0, 10)}T00:00:00.000Z`) : NaN;
  if (!Number.isFinite(start)) {
    return { applicable: false, warning: 'Source excluded: effectiveDate is missing, so the law cannot safely be matched to the relevant date.' };
  }
  if (target < start) return { applicable: false };
  // repealDate is treated as the first day on which the provision is no longer in force.
  if (Number.isFinite(end) && target >= end) return { applicable: false };
  return { applicable: true };
}

export function isIsoDate(value: string): boolean {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const parsed = new Date(`${value}T00:00:00.000Z`);
  return Number.isFinite(parsed.getTime()) && parsed.toISOString().slice(0, 10) === value;
}
