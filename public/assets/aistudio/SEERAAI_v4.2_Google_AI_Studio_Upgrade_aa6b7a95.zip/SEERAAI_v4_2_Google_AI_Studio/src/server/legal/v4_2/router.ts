import { Router, type Request, type Response } from 'express';
import { randomUUID } from 'node:crypto';
import { getAuth, type DecodedIdToken } from 'firebase-admin/auth';
import type { Firestore } from 'firebase-admin/firestore';
import { Timestamp } from 'firebase-admin/firestore';
import { z } from 'zod';
import { answerLegalQuestion } from './service';
import { buildIndexTokens, isIsoDate } from './queryTools';
import type { LegalLanguage, LegalJurisdiction, LegalSourceRecord } from './types';

export interface LegalUserContext { uid: string; claims: DecodedIdToken; }
export interface LegalRouterOptions {
  db: Firestore; // Inject the EXISTING initialized Firestore instance. Never create a new project/database here.
  authorizeUser: (context: LegalUserContext) => Promise<boolean>;
  authorizeReviewer: (context: LegalUserContext) => Promise<boolean>;
  // Check the uploaded file exists in the EXISTING Firebase Storage bucket.
  assertOriginalDocumentExists: (storagePath: string, context: LegalUserContext) => Promise<boolean>;
}

const requestSchema = z.object({
  question: z.string().trim().min(4).max(8000),
  language: z.enum(['om', 'am', 'en']),
  jurisdiction: z.enum(['federal', 'oromia', 'both', 'unknown']).optional(),
  relevantDate: z.string().refine(isIsoDate, 'Use a real ISO date in YYYY-MM-DD format.').optional(),
  facts: z.string().max(12000).optional(),
  compareJurisdictions: z.boolean().optional(),
}).strict();

const reviewSchema = z.object({
  decisionNumber: z.string().trim().min(1).max(100),
  jurisdiction: z.enum(['federal', 'oromia']),
  issuingInstitution: z.string().trim().min(3).max(250),
  decisionDate: z.string().refine(isIsoDate, 'Use a real ISO date in YYYY-MM-DD format.'),
  volume: z.string().max(80).optional(),
  page: z.string().max(80).optional(),
  legalIssueSummary: z.string().trim().min(20).max(5000),
  holdingOrRule: z.string().trim().min(20).max(10000),
  articleNumbers: z.array(z.string().max(80)).max(50).optional(),
  officialSourceName: z.string().trim().min(3).max(250),
  documentStoragePath: z.string().trim().min(3).max(1000),
  verificationNote: z.string().trim().min(20).max(5000),
}).strict();

class RateLimitError extends Error {}

async function enforceUserRateLimit(db: Firestore, uid: string): Promise<void> {
  const now = new Date();
  const minute = Math.floor(now.getTime() / 60000);
  const max = Math.max(1, Math.min(Number(process.env.LEGAL_AI_RATE_LIMIT_PER_MINUTE ?? 12), 60));
  const ref = db.collection('legal_ai_rate_limits').doc(`${uid}_${minute}`);
  await db.runTransaction(async (tx) => {
    const snap = await tx.get(ref);
    const used = Number(snap.exists ? snap.get('count') ?? 0 : 0);
    if (used >= max) throw new RateLimitError('Rate limit exceeded.');
    tx.set(ref, {
      uid,
      windowStart: new Date(minute * 60000).toISOString(),
      count: used + 1,
      expireAt: Timestamp.fromDate(new Date((minute + 120) * 60000)),
    }, { merge: true });
  });
}

async function authenticate(req: Request): Promise<LegalUserContext | null> {
  const authHeader = req.headers.authorization ?? '';
  const match = authHeader.match(/^Bearer\s+(.+)$/i);
  if (!match) return null;
  const claims = await getAuth().verifyIdToken(match[1], true);
  return { uid: claims.uid, claims };
}

export function createLegalAnswerRouter(options: LegalRouterOptions) {
  if (!options.db || typeof options.authorizeUser !== 'function' || typeof options.authorizeReviewer !== 'function' || typeof options.assertOriginalDocumentExists !== 'function') {
    throw new Error('SEERAAI legal router requires the existing Firestore instance, explicit user/reviewer authorization callbacks, and an original-file existence check.');
  }
  const router = Router();

  router.post('/ask', async (req: Request, res: Response) => {
    const requestId = randomUUID();
    try {
      const user = await authenticate(req);
      if (!user) return res.status(401).json({ ok: false, error: 'AUTHENTICATION_REQUIRED', requestId });
      if (!(await options.authorizeUser(user))) return res.status(403).json({ ok: false, error: 'LEGAL_AI_ACCESS_DENIED', requestId });
      const parsed = requestSchema.safeParse(req.body);
      if (!parsed.success) return res.status(400).json({ ok: false, error: 'INVALID_REQUEST', details: parsed.error.issues.map((x: { path: Array<string | number> }) => x.path.join('.')), requestId });
      await enforceUserRateLimit(options.db, user.uid);
      const result = await answerLegalQuestion(options.db, parsed.data as {
        question: string; language: LegalLanguage; jurisdiction?: LegalJurisdiction;
        relevantDate?: string; facts?: string; compareJurisdictions?: boolean;
      }, requestId);
      try {
        await options.db.collection('legal_ai_audit').add({
          requestId,
          uid: user.uid,
          language: result.language,
          jurisdiction: result.jurisdiction,
          relevantDate: result.relevantDate,
          verification: result.verification,
          provider: result.provider ?? null,
          sourceRefs: result.citations.map((source) => source.sourceRef),
          telegramLeadCount: result.researchLeads.length,
          createdAt: Timestamp.now(),
        });
      } catch {
        // Audit write failure is logged without the confidential question or facts.
        console.error('[SEERAAI] audit write failed', requestId);
      }
      return res.status(result.ok ? 200 : 503).json(result);
    } catch (error) {
      if (error instanceof RateLimitError) return res.status(429).json({ ok: false, error: 'RATE_LIMITED', requestId });
      console.error('[SEERAAI] legal route failed', requestId, error instanceof Error ? error.message : 'unknown error');
      return res.status(500).json({ ok: false, error: 'LEGAL_ANSWER_FAILED', requestId });
    }
  });

  // Only an authorized legal-source reviewer can promote a Telegram candidate.
  // Promotion requires manual review details and a stored copy of the original decision.
  router.post('/telegram/candidates/:candidateId/verify', async (req: Request, res: Response) => {
    const requestId = randomUUID();
    try {
      const user = await authenticate(req);
      if (!user) return res.status(401).json({ ok: false, error: 'AUTHENTICATION_REQUIRED', requestId });
      if (!(await options.authorizeReviewer(user))) return res.status(403).json({ ok: false, error: 'SOURCE_REVIEW_PERMISSION_REQUIRED', requestId });
      const candidateId = String(req.params.candidateId ?? '').trim();
      if (!/^[a-f0-9]{64}$/i.test(candidateId)) return res.status(400).json({ ok: false, error: 'INVALID_CANDIDATE_ID', requestId });
      const parsed = reviewSchema.safeParse(req.body);
      if (!parsed.success) return res.status(400).json({ ok: false, error: 'INVALID_REVIEW_DATA', details: parsed.error.issues.map((x: { path: Array<string | number> }) => x.path.join('.')), requestId });

      const data = parsed.data;
      const storageExists = await options.assertOriginalDocumentExists(data.documentStoragePath, user);
      if (!storageExists) return res.status(400).json({ ok: false, error: 'ORIGINAL_DECISION_FILE_NOT_FOUND', requestId });
      const candidateRef = options.db.collection('telegram_candidates').doc(candidateId);
      const decisionRef = options.db.collection('cassation_decisions').doc(`tg_${candidateId}`);
      await options.db.runTransaction(async (tx) => {
        const candidateSnap = await tx.get(candidateRef);
        if (!candidateSnap.exists) throw new Error('CANDIDATE_NOT_FOUND');
        const candidate = candidateSnap.data() as Record<string, unknown>;
        if (candidate.reviewStatus !== 'PENDING_REVIEW') throw new Error('CANDIDATE_ALREADY_REVIEWED');
        const source: LegalSourceRecord = {
          title: `${data.issuingInstitution} — ${data.decisionNumber}`,
          sourceType: 'cassation_decision',
          jurisdiction: data.jurisdiction,
          issuingInstitution: data.issuingInstitution,
          decisionNumber: data.decisionNumber,
          decisionDate: data.decisionDate,
          issueDate: data.decisionDate,
          effectiveDate: data.decisionDate,
          volume: data.volume,
          page: data.page,
          articleNumbers: data.articleNumbers ?? [],
          status: 'VERIFIED',
          sourceAuthenticityConfirmed: true,
          verifiedBy: user.uid,
          verifiedAt: new Date().toISOString(),
          lastReviewedAt: new Date().toISOString(),
          legalIssueSummary: data.legalIssueSummary,
          holdingOrRule: data.holdingOrRule,
          relevantText: String(candidate.messageText ?? ''),
          searchTokens: buildIndexTokens(`${data.decisionNumber} ${data.legalIssueSummary} ${data.holdingOrRule}`, 100),
          officialSourceName: data.officialSourceName,
          officialSourceUrl: typeof candidate.permalink === 'string' ? candidate.permalink : undefined,
          documentStoragePath: data.documentStoragePath,
        };
        tx.create(decisionRef, source);
        tx.update(candidateRef, {
          reviewStatus: 'VERIFIED_AND_IMPORTED',
          sourceStatus: 'VERIFIED_BY_AUTHORIZED_REVIEWER',
          linkedSourceRef: `cassation_decisions/${decisionRef.id}`,
          verificationNote: data.verificationNote,
          verifiedBy: user.uid,
          verifiedAt: new Date().toISOString(),
        });
      });
      return res.status(201).json({ ok: true, requestId, sourceRef: `cassation_decisions/tg_${candidateId}` });
    } catch (error) {
      const message = error instanceof Error ? error.message : 'unknown error';
      if (message === 'CANDIDATE_NOT_FOUND') return res.status(404).json({ ok: false, error: message, requestId });
      if (message === 'CANDIDATE_ALREADY_REVIEWED') return res.status(409).json({ ok: false, error: message, requestId });
      console.error('[SEERAAI] Telegram source review failed', requestId, message);
      return res.status(500).json({ ok: false, error: 'SOURCE_REVIEW_FAILED', requestId });
    }
  });

  return router;
}
