import OpenAI from 'openai';
import { GoogleGenAI } from '@google/genai';
import { z } from 'zod';
import type { LegalLanguage, ModelLegalAnalysis } from './types';

const ruleSchema = z.object({
  sourceRef: z.string().min(1),
  instrumentTitle: z.string(),
  provisions: z.array(z.string()),
  rule: z.string(),
  application: z.string(),
}).strict();
const cassationSchema = z.object({
  sourceRef: z.string().min(1),
  court: z.string(),
  decisionNumber: z.string(),
  volume: z.string().optional(),
  page: z.string().optional(),
  legalIssue: z.string(),
  holding: z.string(),
  factualSimilarity: z.string(),
}).strict();
const analysisSchema = z.object({
  directAnswer: z.string(),
  legalRules: z.array(ruleSchema).max(30),
  comparativeAnalysis: z.object({
    available: z.boolean(),
    federalPosition: z.string(),
    oromiaPosition: z.string(),
    similarities: z.array(z.string()).max(20),
    differences: z.array(z.string()).max(20),
    competenceAndHierarchy: z.string(),
    sourceRefs: z.array(z.string()).max(40),
  }).strict(),
  cassationAnalysis: z.array(cassationSchema).max(30),
  factualApplication: z.string(),
  conclusion: z.string(),
  limitations: z.array(z.string()).max(30),
  furtherFactsNeeded: z.array(z.string()).max(20),
}).strict();

function cleanJson(text: string): string {
  return text.trim().replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/, '');
}

function parseAnalysis(text: string): ModelLegalAnalysis {
  let value: unknown;
  try { value = JSON.parse(cleanJson(text)); }
  catch { throw new Error('AI provider returned invalid JSON for the legal analysis.'); }
  const parsed = analysisSchema.safeParse(value);
  if (!parsed.success) throw new Error(`AI legal analysis failed schema validation: ${parsed.error.issues.slice(0, 3).map((x: { path: Array<string | number> }) => x.path.join('.')).join(', ')}`);
  return parsed.data;
}

function apiClients() {
  const openai = process.env.OPENAI_API_KEY ? new OpenAI({ apiKey: process.env.OPENAI_API_KEY }) : null;
  const gemini = process.env.GEMINI_API_KEY ? new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY }) : null;
  return { openai, gemini };
}

export async function generateLegalAnalysis(prompt: { instructions: string; input: string }): Promise<{ analysis: ModelLegalAnalysis; provider: 'openai' | 'gemini' }> {
  const { openai, gemini } = apiClients();
  const primary = (process.env.LEGAL_AI_PRIMARY ?? 'openai').toLowerCase();
  const openAiModel = process.env.LEGAL_AI_MODEL ?? 'gpt-5';
  const geminiModel = process.env.LEGAL_GEMINI_MODEL ?? 'gemini-flash-latest';
  const errors: string[] = [];

  const runOpenAI = async () => {
    if (!openai) throw new Error('OPENAI_API_KEY is not configured.');
    const response = await openai.responses.create({
      model: openAiModel,
      instructions: prompt.instructions + '\n\nReturn only valid JSON.',
      input: prompt.input,
      store: false,
      reasoning: { effort: (process.env.LEGAL_AI_REASONING_EFFORT as 'low' | 'medium' | 'high') ?? 'high' },
      text: { format: { type: 'json_object' } },
    } as any);
    const output = response.output_text?.trim();
    if (!output) throw new Error('OpenAI returned an empty legal analysis.');
    return parseAnalysis(output);
  };

  const runGemini = async () => {
    if (!gemini) throw new Error('GEMINI_API_KEY is not configured.');
    const response = await gemini.models.generateContent({
      model: geminiModel,
      contents: prompt.input,
      config: { systemInstruction: prompt.instructions, responseMimeType: 'application/json', temperature: 0.1, store: false },
    });
    const output = response.text?.trim();
    if (!output) throw new Error('Gemini returned an empty legal analysis.');
    return parseAnalysis(output);
  };

  const tasks = primary === 'gemini'
    ? [{ name: 'gemini' as const, run: runGemini }, { name: 'openai' as const, run: runOpenAI }]
    : [{ name: 'openai' as const, run: runOpenAI }, { name: 'gemini' as const, run: runGemini }];

  for (const task of tasks) {
    try {
      const analysis = await task.run();
      return { analysis, provider: task.name };
    } catch (error) {
      errors.push(`${task.name}: ${error instanceof Error ? error.message : 'unknown error'}`);
    }
  }
  throw new Error(`All configured AI providers failed. ${errors.join(' | ')}`);
}

export function languageFallback(language: LegalLanguage): string {
  if (language === 'am') return 'በተረጋገጡ ምንጮች ላይ በቂ ማስረጃ ስላልተገኘ አስተማማኝ የሕግ መደምደሚያ መስጠት አልተቻለም።';
  if (language === 'en') return 'There are not enough relevant verified legal sources to provide a reliable legal conclusion.';
  return "Maddoota seeraa mirkanaa\'an keessaa ragaan gahaan waan hin argamneef xumura seeraa amanamaa kennuun hin danda\'amne.";
}
