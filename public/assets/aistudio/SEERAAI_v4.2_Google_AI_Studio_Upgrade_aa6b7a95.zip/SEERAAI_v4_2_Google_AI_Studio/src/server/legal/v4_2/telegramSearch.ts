import { createHash } from 'node:crypto';
import { TelegramClient } from 'telegram';
import { StringSession } from 'telegram/sessions';
import type { Firestore } from 'firebase-admin/firestore';
import type { TelegramCandidate } from './types';
import { extractSearchTokens } from './queryTools';

type ConfiguredChannel = { ref: string; username?: string };
let cachedClient: TelegramClient | null = null;

function parseChannels(): ConfiguredChannel[] {
  const raw = process.env.TELEGRAM_CHANNELS_JSON;
  if (!raw) return [];
  let parsed: unknown;
  try { parsed = JSON.parse(raw); } catch { throw new Error('TELEGRAM_CHANNELS_JSON must be a JSON array.'); }
  if (!Array.isArray(parsed)) throw new Error('TELEGRAM_CHANNELS_JSON must be a JSON array.');
  return parsed.slice(0, 5).map((entry) => {
    if (typeof entry === 'string') {
      const ref = entry.trim().replace(/^https?:\/\/(?:www\.)?t\.me\//i, '').replace(/\/$/, '');
      const isPublicUsername = !/^-?\d+$/.test(ref) && !ref.startsWith('-100');
      return { ref, username: isPublicUsername ? ref.replace(/^@/, '') : undefined };
    }
    if (entry && typeof entry === 'object' && 'ref' in entry && typeof (entry as any).ref === 'string') {
      const value = entry as { ref: string; username?: string };
      const ref = value.ref.trim();
      return { ref, username: value.username?.replace(/^@/, '').trim() };
    }
    throw new Error('Each Telegram channel must be a string or {ref, username}.');
  }).filter((item) => Boolean(item.ref));
}

async function getAuthorizedClient(): Promise<TelegramClient> {
  if (cachedClient?.connected) return cachedClient;
  const apiId = Number(process.env.TELEGRAM_API_ID);
  const apiHash = process.env.TELEGRAM_API_HASH;
  const session = process.env.TELEGRAM_STRING_SESSION;
  if (!Number.isInteger(apiId) || !apiHash || !session) {
    throw new Error('Telegram MTProto is not configured. Set TELEGRAM_API_ID, TELEGRAM_API_HASH and TELEGRAM_STRING_SESSION in server secrets.');
  }
  const client = new TelegramClient(new StringSession(session), apiId, apiHash, {
    connectionRetries: 3,
    retryDelay: 2,
    floodSleepThreshold: 30,
  });
  await client.connect();
  const authorized = await client.isUserAuthorized();
  if (!authorized) {
    await client.disconnect();
    throw new Error('Telegram session is not authorized. Create a new session with scripts/telegram-login.ts.');
  }
  cachedClient = client;
  return client;
}

function safeMessageText(value: unknown): string {
  if (typeof value !== 'string') return '';
  return value.replace(/\u0000/g, '').trim().slice(0, 18000);
}

function makeCandidate(channel: ConfiguredChannel, channelTitle: string, message: any, query: string): TelegramCandidate | null {
  const messageText = safeMessageText(message?.message ?? message?.text);
  if (!messageText || !Number.isInteger(Number(message?.id))) return null;
  const messageId = Number(message.id);
  const username = channel.username;
  const permalink = username ? `https://t.me/${username}/${messageId}` : undefined;
  const material = `${channel.ref}:${messageId}:${messageText}`;
  const candidateId = createHash('sha256').update(material).digest('hex');
  const seconds = Number(message?.date);
  return {
    candidateId,
    channelTitle: channelTitle || channel.ref,
    channelUsername: username,
    messageId,
    messageDate: Number.isFinite(seconds) && seconds > 0 ? new Date(seconds * 1000).toISOString() : undefined,
    messageText,
    permalink,
    searchQuery: query,
    reviewStatus: 'PENDING_REVIEW',
    sourceStatus: 'UNVERIFIED_TELEGRAM_LEAD',
  };
}

async function savePendingCandidate(db: Firestore, candidate: TelegramCandidate): Promise<void> {
  const ref = db.collection('telegram_candidates').doc(candidate.candidateId);
  await db.runTransaction(async (tx) => {
    const existing = await tx.get(ref);
    // Never overwrite a review decision or a linked verified record.
    if (existing.exists) return;
    tx.create(ref, {
      ...candidate,
      createdAt: new Date().toISOString(),
      reviewStatus: 'PENDING_REVIEW',
      sourceStatus: 'UNVERIFIED_TELEGRAM_LEAD',
    });
  });
}

export async function searchTelegramCassation(args: {
  db: Firestore;
  question: string;
  facts?: string;
}): Promise<{ candidates: TelegramCandidate[]; warning?: string }> {
  if (process.env.TELEGRAM_ENABLED !== 'true') {
    return { candidates: [], warning: 'Telegram archive search is disabled (TELEGRAM_ENABLED is not true).' };
  }
  let channels: ConfiguredChannel[];
  try { channels = parseChannels(); } catch (error) {
    return { candidates: [], warning: error instanceof Error ? error.message : 'Telegram channel configuration is invalid.' };
  }
  if (!channels.length) return { candidates: [], warning: 'No authorized Telegram channels are configured.' };

  let client: TelegramClient;
  try { client = await getAuthorizedClient(); } catch (error) {
    return { candidates: [], warning: error instanceof Error ? error.message : 'Telegram connection failed.' };
  }

  const queries = extractSearchTokens(`${args.question} ${args.facts ?? ''}`, 3);
  if (!queries.length) return { candidates: [], warning: 'No useful Telegram search terms were extracted.' };

  const found = new Map<string, TelegramCandidate>();
  for (const channel of channels) {
    let entity: any;
    try { entity = await client.getEntity(channel.ref); }
    catch { continue; }
    const channelTitle = String(entity?.title ?? channel.ref);
    for (const query of queries) {
      try {
        let count = 0;
        for await (const rawMessage of client.iterMessages(entity, { search: query, limit: 15 })) {
          const candidate = makeCandidate(channel, channelTitle, rawMessage, query);
          if (!candidate) continue;
          found.set(candidate.candidateId, candidate);
          count += 1;
          if (count >= 15 || found.size >= 30) break;
        }
      } catch (error) {
        // Continue to other terms/channels; a Telegram FloodWait must not take down legal Q&A.
        if (found.size === 0) {
          return { candidates: [], warning: error instanceof Error ? `Telegram search warning: ${error.message}` : 'Telegram search failed.' };
        }
      }
      if (found.size >= 30) break;
    }
    if (found.size >= 30) break;
  }

  const candidates = [...found.values()];
  for (const candidate of candidates) {
    try { await savePendingCandidate(args.db, candidate); }
    catch { /* Search results remain visible; failed persistence is not source verification. */ }
  }
  return {
    candidates,
    warning: candidates.length
      ? 'Telegram results are research leads only. They are NOT legal authorities until a reviewer checks the original decision and approves the source.'
      : 'No matching Telegram messages were found in the configured channels.',
  };
}

export async function shutdownTelegramClient(): Promise<void> {
  if (cachedClient) {
    await cachedClient.disconnect();
    cachedClient = null;
  }
}
