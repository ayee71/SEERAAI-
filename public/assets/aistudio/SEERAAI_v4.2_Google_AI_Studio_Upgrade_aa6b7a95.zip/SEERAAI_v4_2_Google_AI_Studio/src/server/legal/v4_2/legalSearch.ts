import type { Firestore } from 'firebase-admin/firestore';
import type { LegalJurisdiction, LegalSourceRecord, RetrievedLegalSource } from './types';
import { expandSearchTerms, isStatuteApplicableOnDate, normalizeForSearch } from './queryTools';

const LAW_COLLECTION = 'legal_sources';
const CASSATION_COLLECTION = 'cassation_decisions';
const MAX_CANDIDATES_PER_COLLECTION = 50;

function hasVerifiedProvenance(source: LegalSourceRecord): boolean {
  return source.status === 'VERIFIED'
    && source.sourceAuthenticityConfirmed === true
    && Boolean(source.verifiedBy?.trim())
    && Boolean(source.verifiedAt?.trim())
    && Boolean(source.officialSourceName?.trim() || source.documentStoragePath?.trim() || source.officialSourceUrl?.trim());
}

function validShape(source: LegalSourceRecord): boolean {
  const common = Boolean(source.title?.trim() && source.issuingInstitution?.trim()
    && source.legalIssueSummary?.trim() && source.holdingOrRule?.trim()
    && Array.isArray(source.searchTokens));
  if (!common) return false;
  if (source.sourceType === 'cassation_decision') {
    return Boolean(source.decisionNumber?.trim());
  }
  return Boolean(source.proclamationNumber?.trim() || source.sourceType === 'civil_code'
    || source.sourceType === 'criminal_code' || source.sourceType === 'regulation'
    || source.sourceType === 'directive');
}

function scoreSource(source: LegalSourceRecord, terms: string[]): number {
  const searchable = normalizeForSearch([
    source.title, source.titleOm, source.titleAm, source.titleEn,
    source.legalIssueSummary, source.holdingOrRule, source.relevantText,
    source.proclamationNumber, source.decisionNumber, source.issuingInstitution,
    ...(source.articleNumbers ?? []), ...(source.searchTokens ?? []),
  ].filter(Boolean).join(' '));
  const normalizedIndex = new Set((source.searchTokens ?? []).map(normalizeForSearch));
  let score = 0;
  for (const term of terms) {
    if (searchable.includes(term)) score += 2;
    if (normalizedIndex.has(term)) score += 4;
    if (source.articleNumbers?.some((article) => normalizeForSearch(article) === term)) score += 5;
    if (source.decisionNumber && normalizeForSearch(source.decisionNumber).includes(term)) score += 6;
    if (source.proclamationNumber && normalizeForSearch(source.proclamationNumber).includes(term)) score += 6;
  }
  return score;
}

function normalizeSource(
  collection: string,
  id: string,
  data: FirebaseFirestore.DocumentData,
): RetrievedLegalSource {
  const source = data as LegalSourceRecord;
  return { ...source, id, sourceRef: `${collection}/${id}`, score: 0 };
}

async function retrieveCollection(
  db: Firestore,
  collection: string,
  terms: string[],
): Promise<RetrievedLegalSource[]> {
  // Firestore array-contains-any is capped at 10 query values.
  const snapshot = await db.collection(collection)
    .where('status', '==', 'VERIFIED')
    .where('searchTokens', 'array-contains-any', terms.slice(0, 10))
    .limit(MAX_CANDIDATES_PER_COLLECTION)
    .get();
  return snapshot.docs.map((doc: { id: string; data: () => FirebaseFirestore.DocumentData }) => normalizeSource(collection, doc.id, doc.data()));
}

function filterByJurisdiction(
  rows: RetrievedLegalSource[],
  requested: LegalJurisdiction,
): RetrievedLegalSource[] {
  if (requested === 'federal' || requested === 'oromia') {
    return rows.filter((row) => row.jurisdiction === requested);
  }
  return rows.filter((row) => row.jurisdiction === 'federal' || row.jurisdiction === 'oromia');
}

function selectBalanced(rows: RetrievedLegalSource[], requested: LegalJurisdiction, max: number): RetrievedLegalSource[] {
  const sorted = [...rows].sort((a, b) => b.score - a.score);
  if (requested !== 'both' && requested !== 'unknown') return sorted.slice(0, max);
  const federal = sorted.filter((row) => row.jurisdiction === 'federal');
  const oromia = sorted.filter((row) => row.jurisdiction === 'oromia');
  const chosen = new Map<string, RetrievedLegalSource>();
  // Reserve capacity for both jurisdictions so that one large index does not
  // crowd out the other side of the comparative analysis.
  for (const row of federal.slice(0, Math.ceil(max / 3))) chosen.set(row.sourceRef, row);
  for (const row of oromia.slice(0, Math.ceil(max / 3))) chosen.set(row.sourceRef, row);
  for (const row of sorted) {
    if (chosen.size >= max) break;
    chosen.set(row.sourceRef, row);
  }
  return [...chosen.values()].sort((a, b) => b.score - a.score).slice(0, max);
}

export async function retrieveLegalSources(args: {
  db: Firestore;
  question: string;
  facts?: string;
  jurisdiction: LegalJurisdiction;
  relevantDate: string;
  maxSources?: number;
}): Promise<RetrievedLegalSource[]> {
  const terms = expandSearchTerms(`${args.question} ${args.facts ?? ''}`, 10);
  if (!terms.length) return [];

  const [laws, cases] = await Promise.all([
    retrieveCollection(args.db, LAW_COLLECTION, terms),
    retrieveCollection(args.db, CASSATION_COLLECTION, terms),
  ]);
  const merged = filterByJurisdiction([...laws, ...cases], args.jurisdiction);
  const unique = new Map<string, RetrievedLegalSource>();

  for (const row of merged) {
    if (!hasVerifiedProvenance(row) || !validShape(row)) continue;
    let dateWarning: string | undefined;
    if (row.sourceType !== 'cassation_decision') {
      const temporal = isStatuteApplicableOnDate(row, args.relevantDate);
      if (!temporal.applicable) continue;
      dateWarning = temporal.warning;
    }
    const score = scoreSource(row, terms);
    if (score < 2) continue;
    unique.set(row.sourceRef, { ...row, score, dateWarning });
  }

  return selectBalanced(
    [...unique.values()],
    args.jurisdiction,
    Math.max(1, Math.min(args.maxSources ?? 18, 30)),
  );
}

export const LEGAL_SOURCE_COLLECTIONS = { laws: LAW_COLLECTION, cassation: CASSATION_COLLECTION } as const;
