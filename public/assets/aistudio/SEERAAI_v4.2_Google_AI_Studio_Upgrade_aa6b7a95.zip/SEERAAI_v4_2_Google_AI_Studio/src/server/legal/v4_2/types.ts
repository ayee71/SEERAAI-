export type LegalLanguage = 'om' | 'am' | 'en';
export type LegalJurisdiction = 'federal' | 'oromia' | 'both' | 'unknown';
export type LegalSourceType =
  | 'proclamation'
  | 'regulation'
  | 'directive'
  | 'civil_code'
  | 'criminal_code'
  | 'cassation_decision'
  | 'court_decision'
  | 'official_guideline'
  | 'other';

export interface LegalSourceRecord {
  title: string;
  titleOm?: string;
  titleAm?: string;
  titleEn?: string;
  sourceType: LegalSourceType;
  jurisdiction: 'federal' | 'oromia';
  issuingInstitution: string;
  proclamationNumber?: string;
  decisionNumber?: string;
  volume?: string;
  page?: string;
  articleNumbers?: string[];
  paragraphNumbers?: string[];
  issueDate?: string;
  decisionDate?: string;
  effectiveDate?: string;
  repealDate?: string;
  versionGroupId?: string;
  status: string;
  sourceAuthenticityConfirmed?: boolean;
  verifiedBy?: string;
  verifiedAt?: string;
  lastReviewedAt?: string;
  legalIssueSummary: string;
  holdingOrRule: string;
  relevantText?: string;
  language?: LegalLanguage;
  searchTokens: string[];
  officialSourceName?: string;
  officialSourceUrl?: string;
  documentStoragePath?: string;
}

export interface RetrievedLegalSource extends LegalSourceRecord {
  id: string;
  sourceRef: string; // collection/documentId; avoids document-ID collisions
  score: number;
  dateWarning?: string;
}

export interface TelegramCandidate {
  candidateId: string;
  channelTitle: string;
  channelUsername?: string;
  messageId: number;
  messageDate?: string;
  messageText: string;
  permalink?: string;
  searchQuery: string;
  reviewStatus: 'PENDING_REVIEW';
  sourceStatus: 'UNVERIFIED_TELEGRAM_LEAD';
}

export interface LegalAnswerRequest {
  question: string;
  language: LegalLanguage;
  jurisdiction?: LegalJurisdiction;
  relevantDate?: string; // ISO YYYY-MM-DD; for statutory applicability
  facts?: string;
  compareJurisdictions?: boolean;
}

export interface LegalRuleAnalysis {
  sourceRef: string;
  instrumentTitle: string;
  provisions: string[];
  rule: string;
  application: string;
}

export interface CassationAnalysis {
  sourceRef: string;
  court: string;
  decisionNumber: string;
  volume?: string;
  page?: string;
  legalIssue: string;
  holding: string;
  factualSimilarity: string;
}

export interface ComparativeAnalysis {
  available: boolean;
  federalPosition: string;
  oromiaPosition: string;
  similarities: string[];
  differences: string[];
  competenceAndHierarchy: string;
  sourceRefs: string[];
}

export interface ModelLegalAnalysis {
  directAnswer: string;
  legalRules: LegalRuleAnalysis[];
  comparativeAnalysis: ComparativeAnalysis;
  cassationAnalysis: CassationAnalysis[];
  factualApplication: string;
  conclusion: string;
  limitations: string[];
  furtherFactsNeeded: string[];
}

export interface LegalCitation {
  sourceRef: string;
  title: string;
  sourceType: LegalSourceType;
  jurisdiction: 'federal' | 'oromia';
  issuingInstitution: string;
  proclamationNumber?: string;
  decisionNumber?: string;
  volume?: string;
  page?: string;
  articleNumbers?: string[];
  effectiveDate?: string;
  repealDate?: string;
  officialSourceName?: string;
  officialSourceUrl?: string;
  documentStoragePath?: string;
}

export interface LegalAnswerResponse {
  ok: boolean;
  requestId: string;
  language: LegalLanguage;
  jurisdiction: LegalJurisdiction;
  relevantDate: string;
  verification: 'SOURCE_GROUNDED' | 'INSUFFICIENT_SOURCES' | 'AI_ERROR';
  analysis?: ModelLegalAnalysis;
  citations: LegalCitation[];
  researchLeads: TelegramCandidate[];
  warnings: string[];
  disclaimer: string;
  provider?: 'openai' | 'gemini';
}
