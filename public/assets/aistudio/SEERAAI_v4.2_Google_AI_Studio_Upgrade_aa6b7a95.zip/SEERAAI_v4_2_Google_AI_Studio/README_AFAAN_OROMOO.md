# SEERAAI v4.2 — Google AI Studio integration package

## Kaayyoo

Kuni fooyya'iinsa koodii v2 duraan jiru irratti ijaarame. Appii haaraa hin uumu; Firebase project/database, authentication, Storage, Firestore rules, UI fi FAQ duraan jiran hin jijjiiru. Faayiloota kana appii Google AI Studio Build mode keessatti existing codebase irratti dabali; koodii duraan jiru bakka hin buusin.

## Wantoota fooyya'an

1. **Telegram MTProto / GramJS:** chaanalota `TELEGRAM_CHANNELS_JSON` keessatti hayyama qabuun tarreeffaman qofa sakatta'a. Telegram Bot API qofa irratti hin hirkatu.
2. **Telegram = research lead qofa:** ergaan Telegram argame ofumaan murtii mirkanaa'e hin ta'u. `telegram_candidates` keessatti `PENDING_REVIEW` jedhamee galmaa'a. Reviewer hayyama qabu sanada murtii jalqabaa Firebase Storage keessatti olkaa'ee metadata mirkaneessee booda qofa `cassation_decisions` keessatti `VERIFIED` ta'ee galmaa'a.
3. **Federal–Oromia comparison:** maddoota mirkanaa'an mootummaa Federaalaa fi Oromiyaa lamaan keessaa barbaada; tokko yoo dhabame walbira qabinsa guutuu hin dhiyeessu.
4. **Temporal law control:** seerri hojii irra ture guyyaa dhimmaa irratti hundaa'uun `effectiveDate` fi `repealDate` irratti filatama. Seera fooyya'eef version record adda addaa barbaachisa.
5. **Source provenance:** wabii tokko `status=VERIFIED`, `sourceAuthenticityConfirmed=true`, `verifiedBy`, `verifiedAt`, fi madda jalqabaa ykn faayila kuufame qabaachuu qaba.
6. **Citation filtering:** modeliin `sourceRef` hin argamne caqase yoo ta'e ni haqama. Wabiiwwan deebii keessatti maddoota DB irraa argaman qofa ta'u.
7. **Security:** Firebase ID token mirkaneessa, RBAC callback appii kee irraa dirqama, reviewer endpoint addaan eeggama, rate limit Firestore irratti transaction fayyadama.
8. **Provider fallback:** OpenAI Responses API dursee, Gemini fallback; lamaanuu server-side secrets qofa fayyadamu.

## Koodii dabaluun

Directory `src/server/legal/v4_2/` guutuu gara pirojektii kee keessatti dabali. `src/types/legalAnswerV42.ts`, `src/services/legalAnswerClientV42.ts`, fi `scripts/telegram-login.ts` bakka isaanii irratti galchi. Existing `server.ts`, Firebase admin initialization fi RBAC implementation kee osoo hin ilaaliin hin overwrite godhin.

### Dependencies

`package.json` duraan jiru keessatti dependencies kana qofa dabali (version pin gochuun dura version lockfile pirojektii kee ilaali):

```bash
npm install express firebase-admin openai @google/genai zod telegram
npm install -D tsx @types/node
npm install input
```

`input` script `scripts/telegram-login.ts` local terminal keessatti jalqaba session Telegram uumuuf qofa barbaachisa. Runtime Cloud Run keessatti interactive login hin barbaachisu.

## Google AI Studio

Google AI Studio Build mode full-stack web app keessatti Node.js server runtime fi Settings > Secrets qaba. Existing app kee GitHub irraa import/continue gochuun, Code tab keessaa faayiloota kana dabali. API keys fi Telegram session server-side Secrets keessa kaa'i; `VITE_` prefix hin godhin.

Secrets:

- `OPENAI_API_KEY`
- `GEMINI_API_KEY`
- `LEGAL_AI_PRIMARY=openai`
- `LEGAL_AI_MODEL=gpt-5` (model account/API kee keessatti argamuun isaa mirkaneessi)
- `LEGAL_GEMINI_MODEL=gemini-flash-latest` (model alias account kee keessatti argamu mirkaneessi)
- `LEGAL_AI_REASONING_EFFORT=high`
- `LEGAL_AI_RATE_LIMIT_PER_MINUTE=12`
- `TELEGRAM_ENABLED=true` erga qindaa'ee booda qofa
- `TELEGRAM_API_ID`
- `TELEGRAM_API_HASH`
- `TELEGRAM_STRING_SESSION`
- `TELEGRAM_CHANNELS_JSON` — JSON array channel public ykn account kee seenuuf hayyama qabu

Telegram API ID/Hash `my.telegram.org/apps` irraa argama. `telegram-login.ts` account Telegram hayyama qabuun session uuma. Session string akka passwordtti ilaaluu; secret qofa godhi. Private channel seenuuf account sun miseensa/hayyama qabaachuu qaba. Channel dhuunfaa hayyama malee hin sakatta'in.

## Firebase / Firestore — hin jijjiirin

Router `Firestore` instance duraan initialized ta'e argata. Kanaaf project haaraa hin uumu, database maqaa biraa hin filatu, Firebase Admin irra deebiin hin initialize godhu. Existing project kee keessatti `db` duraan fayyadamaa jirtu import/pass godhi. Kun keessumaa named database akka jiru hin jijjiiru.

`server.ts` keessatti integration fakkeenya:

```ts
import { createLegalAnswerRouter } from './src/server/legal/v4_2/router';
// `db` = existing Admin Firestore instance from your current server bootstrap.
app.use('/api/legal', createLegalAnswerRouter({
  db,
  authorizeUser: async ({ uid, claims }) => existingCanUseLegalAI(uid, claims),
  authorizeReviewer: async ({ uid, claims }) => existingCanVerifyLegalSources(uid, claims),
  assertOriginalDocumentExists: async (storagePath) => {
    const [exists] = await existingAdminStorageBucket.file(storagePath).exists();
    return exists;
  },
}));
```

`existingCanUseLegalAI`, `existingCanVerifyLegalSources` fi `existingAdminStorageBucket` fakkeenya dha: maqaa hojii RBAC fi Firebase Storage bucket appii kee duraanii itti fayyadami. Koodiin kun permission nama hundaaf hin banu. Callback sadeen dirqama; reviewer permission addaa qabaachuu qaba, faayilli murtii jalqabaa Storage keessatti argamuu qaba.

## Frontend integration

Gaaffii formii appii duraan jiru keessatti `currentLang` fi values UI irraa ergi:

```ts
import { askSEERAAIV42 } from './services/legalAnswerClientV42';
const result = await askSEERAAIV42({
  question: questionText,
  language: currentLang, // 'om' | 'am' | 'en' from existing language selector
  jurisdiction: 'both',
  relevantDate: selectedEventDate || undefined,
  facts: additionalFacts,
  compareJurisdictions: true,
});
```

Do not call the legacy FAQ endpoint for this question. Preserve FAQ pages/data, but they must not be an answer source for the new legal research endpoint.

## Firestore record rules

Important migration note: in v4.2, `status` means source-authentication status only (`VERIFIED` or `UNVERIFIED`). Legal temporal status is determined from `effectiveDate` and `repealDate`. Older records using `status=AMENDED`, `HISTORICAL`, or `REPEALED` as lifecycle labels must be reviewed and migrated carefully; do not bulk-mark them verified.

Collections existing / expected:

- `legal_sources`: laws and regulations; one record per legal version.
- `cassation_decisions`: authenticated Federal and Oromia cassation decisions.
- `telegram_candidates`: non-authoritative Telegram message leads pending human review.
- `legal_ai_audit`: minimal metadata only; no full legal questions or confidential case facts.
- `legal_ai_rate_limits`: rate-limit windows; configure Firestore TTL on `expireAt`.

Required provenance fields for `legal_sources` and `cassation_decisions`:

```json
{
  "status": "VERIFIED",
  "sourceAuthenticityConfirmed": true,
  "verifiedBy": "Firebase UID of authorized reviewer",
  "verifiedAt": "ISO-8601 timestamp",
  "officialSourceName": "Official gazette / authenticated cassation volume",
  "documentStoragePath": "verified/legal-source/file.pdf",
  "searchTokens": ["dhaaltummaa", "inheritance", "succession"]
}
```

For a law add a valid `effectiveDate` (required for retrieval), `repealDate` (omit only if still in force and this has been confirmed), and `versionGroupId`. Each amendment/version should be a separate document. Do not merely change the old law's title or status. `repealDate` here means the first day it is no longer applicable. Records lacking `effectiveDate` are deliberately excluded from legal answers until corrected. For case law add `decisionNumber`, `decisionDate`, `volume`, `page`, and issuing court. For Oromia cassation, set `jurisdiction: "oromia"` and exact issuing institution; for Federal cassation, set `jurisdiction: "federal"`.

### Firestore indexes

If Firestore returns an index error, create the composite indexes it links to for each collection:

- `status` ascending + `searchTokens` array-contains
- `status` ascending + `searchTokens` ARRAY_CONTAINS (used by `array-contains-any` queries)

Do not replace or loosen existing Firestore Security Rules. Admin SDK requests bypass client rules, so server-side role callbacks are essential.

## Telegram candidate review workflow

1. A user asks a legal question.
2. Configured Telegram channels are searched by question terms.
3. Matching messages are saved in `telegram_candidates` as `PENDING_REVIEW`.
4. UI/admin review process retrieves the original decision, verifies court, number, volume/page, holding, and checks full original document.
5. Reviewer uploads the original document to Firebase Storage and records its `documentStoragePath`.
6. An authorized reviewer calls `POST /api/legal/telegram/candidates/:candidateId/verify` with complete verification metadata.
7. Only then is a record written to `cassation_decisions` with `status=VERIFIED`.

A Telegram post is not itself proof that the decision number, holding, or page is authentic. The review form should require the original document and a written verification note. The route only permits the authorized reviewer callback configured by your app.

## Iccitii galmee mana murtii

Dhugaa dhimmaa, maqaa abbaa dhimmaa, ragaa iccitii, galmee cufaa, ykn odeeffannoo dhuunfaa gara OpenAI/Gemini erguun dura qajeelfama iccitii, hayyama dhaabbataa fi imaammata daataa mana murtii kee mirkaneessi. Yeroo danda'ametti maqaa fi odeeffannoo nama adda baasu haqi/anonymize godhi. Koodiin kun full question/facts hin log godhu; garuu AI provider irratti data processing amma iyyuu ni jira.

## Important legal/technical limits

- Telegram search currently indexes message text in configured channels; it does not download or OCR attached PDFs. PDF ingestion must be implemented as a separate authorized upload/parser workflow.
- Telegram search is not a universal global search. Only configured channels accessible to the authenticated MTProto account are searched.
- Keyword + curated synonym search is better than v2 but is not a full semantic/vector search engine. Add a controlled search index later if archive size and recall tests require it.
- A model cannot authenticate an original law or judgment. Human source verification remains compulsory.
- The app cannot be described as 10/10 production-certified until real data ingestion, access-control testing, load/rate testing, full build, and legal expert validation pass in your actual Google AI Studio project.

## Quality checks

Run in a staging branch/environment:

```bash
npx tsx --test tests/queryTools.test.ts
npm run build
```

Test questions should include Oromo, Amharic and English, and include (i) a law active on the event date, (ii) an amended/repealed law, (iii) both federal and Oromia sources, (iv) same legal issue with a Federal cassation and Oromia cassation decision, (v) a misleading Telegram lead, (vi) missing sources, (vii) unauthorized user/reviewer, and (viii) rate-limit exhaustion.
