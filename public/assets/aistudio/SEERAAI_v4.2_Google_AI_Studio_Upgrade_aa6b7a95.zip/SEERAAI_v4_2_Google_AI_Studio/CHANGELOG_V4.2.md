# SEERAAI v4.2 — change log

## Fixed from v2 baseline
- Removed the broken Latin-script English detection regex; language is now explicitly passed from the existing UI selector.
- Removed Firestore creation/selection from the route; the pre-initialized existing database must be injected.
- Replaced the permissive optional RBAC comment with required authorization callbacks for ordinary users and source reviewers.
- Added Firestore transaction rate limiting.
- Uses collection-qualified source references to prevent document ID collisions across collections.
- Filters statutes against effectiveDate/repealDate; laws missing effectiveDate are excluded; amended versions must be stored as separate dated records.
- Requires source provenance before retrieval.
- Adds separate Federal/Oromia coverage balancing when comparing jurisdictions.
- Overwrites model-generated case identity/article metadata with verified Firestore record values.
- Adds GramJS MTProto search of configured authorized Telegram channels.
- Saves Telegram messages only as pending research leads; never injects them into model legal authority context.
- Adds a reviewer-only promotion endpoint that requires original-file storage path and detailed verification metadata.
- Uses JSON output validation and filters every generated source reference against the verified retrieval result.
- Writes only minimal audit metadata.

## Not represented as completed
- The code is not merged into the user's Google AI Studio project.
- Telegram API credentials/session/channel permissions have not been configured or tested.
- Real court/legal-source data has not been migrated or authenticated.
- Existing RBAC callback names and server bootstrap paths must be wired to the actual application.
- Full PDF ingestion/OCR, vector search, load testing and legal expert validation remain separate tasks.
