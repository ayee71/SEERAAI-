import { test } from 'node:test';
import assert from 'node:assert/strict';
import { detectLanguage, expandSearchTerms, extractSearchTokens, isIsoDate, isStatuteApplicableOnDate } from '../src/server/legal/v4_2/queryTools';

test('Oromo and Amharic query terms are normalized', () => {
  assert.ok(extractSearchTokens('Dhaaltummaa abbaa qabeenyaa').includes('dhaaltummaa'));
  assert.ok(extractSearchTokens('የውርስ ጉዳይ').includes('ውርስ'));
});

test('search expansion adds legal concept synonyms without changing the question', () => {
  const expanded = expandSearchTerms('dhaaltummaa');
  assert.ok(expanded.includes('inheritance'));
  assert.ok(expanded.includes('succession'));
});

test('Amharic script is detected; Latin script defaults to Oromo unless UI tells us otherwise', () => {
  assert.equal(detectLanguage('የውርስ ጉዳይ'), 'am');
  assert.equal(detectLanguage('Dhaaltummaa'), 'om');
  assert.equal(detectLanguage('What is inheritance?', 'en'), 'en');
});

test('effective and repeal dates are applied inclusively/exclusively', () => {
  assert.equal(isStatuteApplicableOnDate({ effectiveDate: '2018-01-01', repealDate: '2022-01-01' }, '2019-01-01').applicable, true);
  assert.equal(isStatuteApplicableOnDate({ effectiveDate: '2018-01-01', repealDate: '2022-01-01' }, '2017-12-31').applicable, false);
  assert.equal(isStatuteApplicableOnDate({ effectiveDate: '2018-01-01', repealDate: '2022-01-01' }, '2022-01-01').applicable, false);
  assert.equal(isIsoDate('2024-02-31'), false);
  assert.equal(isIsoDate('2024-02-29'), true);
});
