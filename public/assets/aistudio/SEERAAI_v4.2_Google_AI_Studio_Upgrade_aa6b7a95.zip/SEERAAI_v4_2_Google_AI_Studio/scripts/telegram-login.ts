/*
Run this ONCE in a trusted administrator's local terminal, not as a public web route.
Install: npm install telegram input
Run: npx tsx scripts/telegram-login.ts
Copy the printed session string directly into Google AI Studio > Settings > Secrets
as TELEGRAM_STRING_SESSION. Never commit it, email it, or place it in frontend code.
*/
import { TelegramClient } from 'telegram';
import { StringSession } from 'telegram/sessions';
import input from 'input';

async function main(): Promise<void> {
  const apiId = Number(process.env.TELEGRAM_API_ID);
  const apiHash = process.env.TELEGRAM_API_HASH;
  if (!Number.isInteger(apiId) || !apiHash) throw new Error('Set TELEGRAM_API_ID and TELEGRAM_API_HASH in your local shell first.');
  const client = new TelegramClient(new StringSession(''), apiId, apiHash, { connectionRetries: 5 });
  await client.start({
    phoneNumber: async () => input.text('Telegram phone number: '),
    password: async () => input.text('Telegram two-step verification password (if enabled): '),
    phoneCode: async () => input.text('Telegram login code: '),
    onError: (error: Error) => console.error('Telegram login error:', error),
  });
  console.log('TELEGRAM_STRING_SESSION (store as server-side secret; do not share):');
  console.log(client.session.save());
  await client.disconnect();
}

main().catch((error) => {
  console.error('Telegram login setup failed:', error instanceof Error ? error.message : 'unknown error');
  process.exitCode = 1;
});
